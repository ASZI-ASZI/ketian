//引入模块
const express = require("express");
//引入mysql连接池对象
const query = require("../util/query.js");

//创建空路由器
let router = express.Router();

//挂载路由
//  
//==============================================
// 1 
// 参数名  参数说明  备注
// 无参数
router.get("/cplist", async (req, res) => {

    //执行Query
    try {
        // 建Sql 语句 获取商品数据
        let sql = "select name_title as title,cpgg_title,img,oprice,sprice,header,cover,nbs_title,spxq_title,spxq_descs,numb,avatar from home ";   
         
        let cplist = await query(sql);       
        

        res.send({ code: 1, msg: `查询成功`, data:cplist });
    } catch (error) {
        res.send({ code: -1, msg: "Query异常,error:" + error });
    }
});

// 参数名  参数说明  备注
// 无参数
router.get("/tjlist", async (req, res) => {

    //执行Query
    try {
        // 建Sql 语句 获取商品数据        
        
        let sql = "select name_title as title,cpgg_title,img,oprice,sprice,header,cover,nbs_title,spxq_title,spxq_descs,numb,avatar from home where tj_index > 0 LIMIT 2 "; 
        let tjData = await query(sql); 
        

        res.send({ code: 1, msg: `查询成功`, data:tjData });
    } catch (error) {
        res.send({ code: -1, msg: "Query异常,error:" + error });
    }
});


//===============================================
//导出路由器
module.exports = router;