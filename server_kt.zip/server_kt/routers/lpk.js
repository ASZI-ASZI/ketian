//引入模块
const express = require("express");
//引入mysql连接池对象
const query = require("../util/query.js");

//创建空路由器
let router = express.Router();
//挂载路由
//  
//==============================================
// 1 
// 参数名  参数说明  备注
// 无参数
router.get("/list", async (req, res) => {

  //执行Query
  try {
    // 建Sql 语句 获取推荐商品数据
    let sql = "SELECT  title, time, zk, `name`  from lpk ORDER BY id";

    let result = await query(sql);
    let data = result;
    res.send({ code: 1, msg: `查询礼品卡列表成功`, data });
  } catch (error) {
    res.send({ code: -1, msg: error.message });
  }

});

//===============================================
//导出路由器
module.exports = router;