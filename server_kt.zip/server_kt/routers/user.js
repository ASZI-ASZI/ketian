//引入模块
const express = require("express");
//引入上一级目录下的mysql的Query对象
const query = require("../util/query.js");
const { md5 } = require('../util/md5.js');
const Token = require('../util/token.js');

//创建空路由器
let router = express.Router();

//===============================================
//登录用户 POST /login  token登录验证
router.post('/login', async (req, res) => {
  try {
    //1.1获取数据
    let userLogin = req.body;
    //1.2验证各项数据是否为空
    if (!userLogin.name) throw "用户名不能为空";
    if (!userLogin.pwd) throw "密码不能为空";

    //执行SQL语句,查看是否是否有这样的用户
    let sql = `SELECT id,name,pwd,salt FROM user WHERE name ="${userLogin.name}"`;

    let result = await query(sql);
    //判断查询的结果（数组）长度是否大于0,如果大于0，说明查询到数据，有这个用户
    if (result.length > 0) {
      let user = result[0];
      if (user.pwd = md5(userLogin.pwd + user.salt)) {
        //密码正确,登陆成功后,生成Token,并设置Token携带的信息
        let payload = {
          userId: user.id,
          userName: user.name,
        };
        //jwt--jsonwebtoken第三方库生成Token
        let token = Token.sign(payload);
        
        //删除不需要返回的用户信息
        delete user.pwd;
        delete user.salt;
        res.send({ code: 1, msg: "登录成功", data: { user, token } });
        return;
      }
    } else {
      res.status(401).send({
        code: 401,
        msg: "用户名或密码错误",
        data: {}
      })
    }
  } catch (error) {
    res.send({ code: -1, msg: "Query异常,error:" + error });
  }
});

//验证用户是否已经登录接口 Token验证
router.get("/islogin", (req, res) => {
  const token = req.headers.authorization // 取到请求头中Token

  let result = Token.verify(token);
  if (result.code == 1) {
    let user = result.data;
    res.send({ code: 1, msg: "已登录", data: { user, token } });
  } else {
    res.send({
      code: 401,
      msg: "Token错误，请登录验证!",
      data: {}
    });
  }
});


//===============================================
//用户注册
router.post("/register", async (req, res) => {  
  //1.1获取post请求的数据
  let user = req.body;
  //1.2验证各项数据是否为空
  try {
    if (!user.name) throw "用户名不能为空";
    if (!user.pwd) throw "密码不能为空";
    if (!user.phone) throw "电话不能为空";
    if (!user.address) throw "地址不能为空";
    
    //生成盐（作料）,密码MD5加密
    
    user.pwd = md5(user.pwd); //密码=MD5(明码)

    //1.3执行SQL语句,将注册的数据插入到user数据表中
    let sql = "INSERT INTO user SET ?";
    let result = await query(sql, [user]);
    if (result.affectedRows > 0) {
      let data = { user: { id: result.insertId, name: user.name } };
      res.send({ code: 1, msg: "注册成功", data });
    } else {
      throw result;
    }
  } catch (error) {
    res.send({ code: -1, msg: `注册失败, 错误信息: ${error}` });
  }
});

//以下可以继续添加需要的路由接口........................
//更过功能的实现，可以参考项目源码 https://gitee.com/watchping/vue-myshop

//===============================================
//导出路由器
module.exports = router;
