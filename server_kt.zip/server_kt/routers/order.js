//引入模块
const express = require("express");
//引入mysql连接池对象
const query = require("../util/query.js");

//创建空路由器
let router = express.Router();
//挂载路由
//  
//==============================================
// 1 
// 参数名  参数说明  备注
// 无参数
router.get("/list", async (req, res) => {

    //执行Query
    try {
        // 建Sql 语句 获取推荐商品数据
        let sql_all = "SELECT  id, order_number, `status`, get_mode, location, time,'全部' as type  from `v_order`";   
        let sql_ldkq = "SELECT  id, order_number, `status`, get_mode, location, time, type  from `v_order` where type = '立等可取'"
        let sql_yydd = "SELECT  id, order_number, `status`, get_mode, location, time, type  from `v_order` where type = '预约订单'"


        let ret = [];

        let list = await query(sql_all); 
        let listData=[];              
        for(let i =0;i<list.length;i++){
            let data = list[i];            
            sql = `SELECT  name ,price ,number from order_detail where order_id = ${data.id}`;
            let order_Item = await query(sql); 
            data.order_Item = order_Item;
            listData.push(data);
        }
        ret.push({
            id:1,
            type: '全部',
            listData,
        })


        list = await query(sql_ldkq); 
        listData=[];              
        for(let i =0;i<list.length;i++){
            let data = list[i];            
            sql = `SELECT  name ,price ,number from order_detail where order_id = ${data.id}`;
            let order_Item = await query(sql); 
            data.order_Item = order_Item;
            listData.push(data);
        }
        ret.push({
            id:2,
            type: '立等可取',
            listData,
        })

        list = await query(sql_yydd); 
        listData=[];              
        for(let i =0;i<list.length;i++){
            let data = list[i];            
            sql = `SELECT  name ,price ,number from order_detail where order_id = ${data.id}`;
            let order_Item = await query(sql); 
            data.order_Item = order_Item;
            listData.push(data);
        }
        ret.push({
            id:3,
            type: '预约订单',
            listData,
        })

        
        

        res.send({ code: 1, msg: `查询成功`, data:ret });
    } catch (error) {
        res.send({ code: -1, msg:  error });
    }
});

//===============================================
//导出路由器
module.exports = router;