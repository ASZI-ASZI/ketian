//引入模块
const express = require("express");
//引入mysql连接池对象
const query = require("../util/query.js");

//创建空路由器
let router = express.Router();

//挂载路由
//  
//==============================================
// 1 
// 参数名  参数说明  备注
// 无参数
router.get("/list", async (req, res) => {

    //执行Query
    try {
        // 建Sql 语句 获取推荐商品数据
        let sql_tj = "select name_title as title ,img, sprice,avatar,spxq_title,spxq_descs,nbs_title oprice from goods where tj_index > 0 LIMIT 2 ";   
        let tjData = await query(sql_tj); 

        //建sql语句  获取商品分类信息
        let sql = "select id,name from goods_class  ORDER BY sort";
        let result = await query(sql);
        let goods_class = result;

        let goods = [];
        for(let i =0;i<goods_class.length;i++){
            let _goods = {name: goods_class[i].name};
            let sql2 = `select * from goods where class_id = ${goods_class[i].id}` ; 
            let content = await query(sql2);
            content.forEach(item =>{                
                item.tjData = tjData
            });

            _goods.content = content;
            goods.push(_goods);
        }

        res.send({ code: 1, msg: `查询成功`, data:goods });
    } catch (error) {
        res.send({ code: -1, msg: "Query异常,error:" + error });
    }
});



//===============================================
//导出路由器
module.exports = router;