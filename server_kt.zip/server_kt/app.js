
const express = require("express");
const cors = require('cors');

//导入路由模块
const userRouter = require("./routers/user.js");
const newsRouter=require('./routers/news');
const goodsRouter=require('./routers/goods');
const orderRouter=require('./routers/order');
const couponRouter=require('./routers/coupon');
const addressRouter=require('./routers/address');
const cartRouter=require('./routers/cart');
const homeRouter=require('./routers/home');
const app = express();

//跨域设置
let corsOptions = {
  origin:[/http/,"http://localhost:80"], //数组元素可以是字符串，正则表达式
  credentials:true,
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}
app.use(cors(corsOptions));

app.use(express.json()); //在其他路由中间件前（尽可能靠前，以能够通过bodyPaser获取req.body）
app.use(express.urlencoded({ extended: false }));

//托管静态资源
app.use(express.static("public"));

//注册路由,建议放在其他中间件的后面
app.use("/user",userRouter);
app.use("/news",newsRouter);
app.use("/cart",cartRouter);
app.use("/goods",goodsRouter);
app.use("/order",orderRouter);
app.use("/coupon",couponRouter);
app.use("/address",addressRouter);
app.use("/home",homeRouter);


//可以继续添加其他模块的路由....(在开始处要导入该路由的模块)
//进一步功能的实现，可以参考项目源码 https://gitee.com/watchping/vue-myshop ......


//启动服务
const port = 5050;
app.listen(port, () => console.log(`Server App listening on port:${port}`));
