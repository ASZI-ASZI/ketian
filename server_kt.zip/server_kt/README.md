# vue-shop

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run dev
```

# 注意
## util\pool.js中的数据库名要改为你自己的数据库，并检查设置的数据库的端口号 用户名 密码是否正确
## 进一步功能的实现，可以参考项目源码 https://gitee.com/watchping/vue-myshop