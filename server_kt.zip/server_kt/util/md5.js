const crypto = require('crypto');

function md5(content) {
    let result = crypto.createHash('md5').update(content).digest("hex");
    return result; 
}

module.exports = { md5 }
