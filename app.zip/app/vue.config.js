
const { resolve } = require("path");
const path = require("path");

// 构建工具函数
const utils = {
  // 处理路径
  resolve (dir) {
    return path.join(__dirname, dir);
  }
}

// 环境配置
const configEnv = require("./config");

// 判断是否是生产环境
let isProd = process.env.NODE_ENV == "production" ? true : false;


module.exports = {
	lintOnSave:false,
	publicPath: "./",
	devServer:{
		host:'0.0.0.0',
		port: 8080,
		open: true,
		https: false,
		// 设置代理
		proxy: {
			[configEnv.baseApi]: {
	  
			  target: configEnv.target,  // 目标 API 地址
	  
			  changeOrigin: true, //允许跨域
			  pathRewrite: {
				[`^${configEnv.baseApi}`]: "",  //重写路径
			  },
			},
		},
		
	},
	css: {
		loaderOptions: {
			postcss: {
				plugins: [
					require("autoprefixer")({
						// 配置使用 autoprefixer
						overrideBrowserslist: ["last 15 versions"]
					}),
					require("postcss-pxtorem")({
						rootValue: 75, // 换算的基数
						// 忽略转换正则匹配项。插件会转化所有的样式的px。
						// 比如引入了三方UI，也会被转化。目前我使用 selectorBlackList字段，来过滤
						//如果个别地方不想转化px。可以简单的使用大写的 PX 或 Px 。
						selectorBlackList: ["ig"],
						propList: ["*"],
						exclude: /node_modules/
					})
				]
			}
		}
	}
};
