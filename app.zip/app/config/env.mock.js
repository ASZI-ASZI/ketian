
// 模拟数据配置
module.exports = {
    modeName: '模拟数据模式',
    title: 'myshop(mock)',
    baseApi: '/mock',
    target: './',
    //target: "https://www.fastmock.site/mock/4065436981794d02775c54b5d2e22e74/common-test/api", // 代理的地址(后端测试api地址)    
    publicPath: './'
}