let routes = [
  {
    path:'/',
    name:'layout',
    component:()=>import('@/views/layout'),
    children:[
      {
        path:'/',
        name:'home',
        component:()=>import('@/views/home/index'),
		meta:{showTab:true}
		
      },
      {
        path:'/shops',
        name:'shops',
        component:()=>import('@/views/shops/index'),
		// meta:{showTab:true}
		
      },
 
      {
        path:'/cart',
        name:'cart',
        component:()=>import('@/views/cart/index'),
		meta:{showTab:true}
      },
      {
        path:'/user',
        name:'user',
        component:()=>import('@/views/user/index'),
		meta:{showTab:true}
      },
	  // 商品详情
	  {
	    path:'/goods_details',
	    name:'goods_details',
	    component:()=>import('@/views/goods_details/index'),
		
	  },
	  // 登录
	  {
		  path:'/login',
		  name:'login',
		  component:()=>import('@/views/login')
	  },
	  {
		  path:'/register',
		  name:'register',
		  component:()=>import('@/views/register')
	  },
	  // 消息中心
	  {
	  		  path:'/news',
	  		  name:'news',
	  		  component:()=>import('@/views/news')
	  },
	  {//优惠券
		  path:'/coupon',
		  name:'coupon',
		  component:()=>import('@/views/coupon')
	  },
	  {//无效的优惠券
		  path:'/invalid',
		  name:'invalid',
		  component:()=>import('@/views/coupon/invalid')
	  },
	  	  {//礼品卡
			path:'/lpk',
			name:'lpk',
			component:()=>import('@/views/lpk')
		},
	  {//奶爸钱包
		  path:'/nbqb',
		  name:'nbqb',
		  component:()=>import('@/views/nbqb')
	  },
	  {//充值钱包
		  path:'/czqb',
		  name:'czqb',
		  component:()=>import('@/views/czqb')
	  },
	  {//确认定单
		  path:'/qrdd',
		  name:'qrdd',
		  component:()=>import('@/views/qrdd')
	  },
	  // 收货地址
	  {
		  path:'/address',
		  name:'address',
		  component:()=>import('@/views/address')
	  },
	  // 确认定单
	  {
		  path:'/affirm',
		  name:'affirm',
		  component:()=>import('@/views/affirm')
	  },
	  // 我的订单
	  {
		  path:'/order',
		  name:'order',
		  component:()=>import('@/views/order')
	  },
	  //发票管理
	  {
		path:'/bill' ,
		name:'bill',
		component:()=>import('@/views/bill')
	  },
	  //兑换优惠
	  {
		path:'/convert' ,
		name:'convert',
		component:()=>import('@/views/convert')
	  },
	   //企业账户
	   {
		path:'/zhye' ,
		name:'zhye',
		component:()=>import('@/views/zhye')
	  },

	  //企业账户
	  {
		path:'/enterprise' ,
		name:'enterprise',
		component:()=>import('@/views/enterprise')
	  },
	  // 我的客服
	  {
		  path:'/service',
		  name:'service',
		  component:()=>import('@/views/service')
	  },
	  // 店铺地址
	  {
		  path:'/store',
		  name:'store',
		  component:()=>import('@/views/store')
	  },
	  // 门店详情
	  {
		path:'/outlet',
		name:'outlet',
		component:()=>import('@/views/store/outlet')
	  },
	  //日历
	  {
		path:'/calendar',
		name:'calendar',
		component:()=>import('@/views/home/calendar')
	  },
 //定位城市
 {
	path:'/location',
	name:'location',
	component:()=>import('@/views/location/index')
  }
    ]
  }
]
export default routes
