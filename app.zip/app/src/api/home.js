import http from "@/utils/request";

export function getHomeCpList()
{
    return http.request({
        url: "/home/cplist",
        method: "get",       
    });
} 


export function getHomeTjList()
{
    return http.request({
        url: "/home/tjlist",
        method: "get",       
    });
} 