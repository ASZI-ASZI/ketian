import http from "@/utils/request";

/***** 用户(User) 模块 *******/
export function isLogin()
{
    return http.request({
        url: "/user/islogin",
        method: "get",       
    });
} 

export function login(params)
{ 
    return http.request({
        url: "/user/login",
        method: "post", 
        data: params,
    });
} 

export function register(params)
{
    return http.request({
        url: "/user/register",
        method: "post", 
        data:params,
    });
} 