import http from "@/utils/request";

// 
// 参数名  参数说明  备注
// 无参数
export function getGoodsList()
{
    return http.request({
        url: "goods/list",
        method: "get",         
    });
}

// 参数名  参数说明  备注
// 无参数
export function getCnxhList()
{
    return http.request({
        url: "goods/cnxhlist",
        method: "get",         
    });
}