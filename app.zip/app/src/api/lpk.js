import http from "@/utils/request";

// 
// 参数名	参数说明	备注
// 无参数
export function getlpkList()
{
    return http.request({
        url: "lpk/list",
        method: "get",         
    });
}