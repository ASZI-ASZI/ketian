<template>
	<div class="user_gncd">
		<!-- 列表 -->
		<div class="tb_title">
			<div class="content" v-for="(item, index) in resData" :key="index"
			@click="userInfo(item)">
				<div class="tb_titles">
					<van-icon size="20" :name="item.icon" />
					<span class="title">{{ item.title }}</span>
				</div>
				<div class="icon"><van-icon color="#ededed" size="20" name="arrow" /></div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		resData:Array
	},
	methods: {
		userInfo(item) {
			this.$emit('userInfo',item)
		}
	},
};
</script>

<style lang="scss" scoped>
// 用户功能菜单
.user_gncd {
	display: flex;
	margin: 0 20px 20px 20px;
	height: 500px;
	width: 710px;
	background-color: white;
	border-radius: 10px;
	// 列表
	.tb_title {
		margin: 41px 44px 0 44px;
		width: 622px;
		height: 418px;
		font-size: 30px;
		background-color: white;
		.content {
			display: flex;
			justify-content: space-between;
			margin-bottom: 41px;
			.tb_titles {
				display: flex;
				height: 41px;
				line-height: 41px;
				text-align: centr;
				.title {
					margin-left: 36px;
				}
			}
		}
	}
}
</style>
