<template>
	<div class="user_info">
		<van-row>
		  <van-col span="6" v-for="(item,index) in resData" :key="index"
		  @click="info(item)">
			  <div class="border" >
				  <div class="c">
					  <div class="title">{{item.title}}</div>
					  <div class="subtitle">{{item.subtitle}}</div>
				  </div>
			  </div>
		  </van-col>
		</van-row>
	</div>
	
</template>

<script>
	export default {
		props: {
			resData:Array
		},
		methods:{
			info(item){
				this.$emit('info',item)
			}
		}
	}
</script>

<style lang="scss" scoped>
//余额、优惠、礼品、钱包
.user_info {
	margin: -90px 20px 20px 20px;
	height: 132px;
	width: 710px;
	background-color: white;
	border-radius: 10px;
	.van-row {
		display: flex;
		justify-content: space-between;
		line-height: 132px;
		height: 132px;
		text-align: center;
		border-radius: 10px;
		font-size: 30px;

		.van-col {
			display: flex;
			flex-direction: column;
			line-height: 50px;
			justify-content: center;

			// 右边边线
			.border {
				// border-right: 1px solid #AEAEAE;
				height: 40px;
				.c {
					margin-top: -30px;
					//--元
					.title {
						color: #6d86c4;
						font-size: 28px;
					}
					// 账户余额
					.subtitle {
						color: #aeaeae;
					}
				}
			}
		}
	}
}

</style>