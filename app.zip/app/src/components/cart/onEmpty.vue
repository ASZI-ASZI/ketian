<template>
	<!-- 不为空 -->
	<div class="onEmpty">
		<!-- header -->
		<div class="cart_header">
			<div class="cart_title">
				订单
				<small class="psxx">自提/配送</small>
			</div>
			<div class="cart_clear" @click="delAll">
				<van-icon name="delete" />
				清空
			</div>
		</div>
		<!-- 分割线 -->
		<van-divider />
		<!-- content -->
		<div class="gwdd">
			<van-swipe-cell
			v-for="(item, index) in resData" :key="index">
				<div class="content">
					<!-- 订单产品规格 -->
					<div class="cpgg">
						<!-- checkbox  -->
						<van-checkbox 
						v-model="item.checked" 
						label-disabled 
						checked-color="#6d86c4" 
						icon-size="24"
						@click="selectItem(index)" />

						<!-- 产品图片 -->
						<van-image fit="cover" :src="item.cover"></van-image>
						<!-- 标题、价格 -->
						<div class="cpgg_title">
							<span>{{ item.cpgg_title }}</span>
							<div class="view-text">
								<small v-for="(ms,msIndex) in item.attrs" :key="msIndex">
									{{ms.list[ms.selected].name+'/'}}
								</small>
							</div>
							<com-price 
								:Sprice="item.Sprice" 
								:Oprice="item.Oprice" 
								:isShow="false">
							</com-price>
							
						</div>
						
					</div>
					
					<!-- 进步器 -->
					<div class="buttons">
						<van-stepper 
							v-model="item.count"
							theme="round" button-size="20"
							disable-input
							@overlimit="del(index)"
						/>
					</div>
				</div>
				<template #right>
					<van-button  @click="edit(index)"  class="cellDel" square type="danger" text="编辑" />
				</template>
				<!-- 分割线 -->
				<van-divider />
			</van-swipe-cell>

			<!-- 合计 -->
			<slot name="checked"></slot>
		</div>
	</div>
</template>

<script>
// price
import ComPrice from '@/components/common/price.vue';
export default {
	components: {ComPrice},
	props: {resData: Array},
	methods: {
		// 编辑
		edit(index) {
			this.$emit('edit',index)
		},
		
		// 选中或取消某一个商品
		selectItem(index){
			this.$emit('selectItem',index)
		},
		// 单个删除
		del(i){
			this.$dialog.confirm({
			  message: '客官，您确定不要了吗?'
			}).then(() => {
				this.$emit('del',i)
			})
			
		},
		//清空
		delAll(){
			this.$dialog.confirm({
			  message: '客官，您确定清空购物车吗?'
			}).then(() => {
				this.$emit('delAll',)
			})
			
		},
		
		
		
	}
};
</script>

<style lang="scss" scoped>

@import '~@/assets/scss/onEmpty';
</style>
