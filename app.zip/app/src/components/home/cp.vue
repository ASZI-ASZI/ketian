<template>
	<div>
		<!-- 产品 -->
		<div class="cps">
			<!-- 内容 -->
			<div class="cp" v-for="(item,index) in cpList" :key="index"
			@click="toDetails(item)">
				<van-image fit="cover" :src="item.img"></van-image>
				<!-- info -->
				<div class="info">
					<!-- 潮品自营 -->
					<div class="cpzy">{{item.header}}</div>
					<!-- 标题 -->
					<div class="title">{{item.cpgg_title}}</div>
					<!-- 价格、购物按钮 -->
					<div class="pb">
						<div class="price">
							<div class="Sprice">￥{{item.sprice}}</div>
							<div class="Oprice">￥{{item.oprice}}</div>
						</div>
						<div class="button">
							<van-icon name="add" size="25" />
						</div>
					</div>
					<!-- 销售信息 -->
					<div class="xsxx">已售卖{{item.numb}}+件</div>
				</div>
			</div>
		</div>
		
	</div>
</template>

<script>

export default {
	
	props: ["cpList"],
	
	methods:{
		// 商品详情
		toDetails(item){
			this.$emit('toDetails',item)
		}
	}
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/cp'
</style>
