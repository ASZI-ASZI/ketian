<template>
  <div class="my-swipe">
	   <van-swipe vertical 
		   :autoplay="3000" 
		   indicator-color="white" 
		   

		  >
			 <van-swipe-item v-for="(item,index) in swipeList" :key="index"
			 @click="event(item)">
			   <img v-lazy="item.img" />
			 </van-swipe-item>
	   </van-swipe>
  </div>
</template>

<script>
  export default{
    props: {
      swipeList:Array,
	  // 高度
	  height:{
		  type:String,
		  default:"200"
	  }
    },
	// 动态设置高度
	computed: {
		getStyle() {
			return `height: ${this.height}px;` 
		}
	},
    methods: {
      event(item){
        this.$emit('event',item)
      }
    },
  }
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/swipe'
</style>
