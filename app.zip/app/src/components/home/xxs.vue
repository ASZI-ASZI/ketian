<template>
	<div>
		<!-- 新鲜事内容 -->
		<van-swipe :loop="false" :show-indicators="false" :width="250">
			<van-swipe-item v-for="(item, index) in xxsList" :key="index">
				<video width="250"  controls="true" muted autoplay="true" loop="loop">
					<source  :src="item.img" type="video/mp4" />
				</video>
			</van-swipe-item>
		</van-swipe>
	</div>
</template>

<script>
export default {
	props: {
		xxsList: Array
	}
};
</script>

<style lang="scss" scoped>

// 新鲜事内容
.van-swipe {
	margin-top: 17px;
	width: 710px;
}
.van-swipe-item {
	margin: 0 17px 0 0;
	border-radius: 10px;
	width: 100%;
	height: 310px;
	// background-color: #f9fafa;
	
	::v-deep .van-image__img {
		width: 100%;
		height: 310px;
		border-top-left-radius: 10px;
		border-top-right-radius: 10px;
		
	}
}
</style>
