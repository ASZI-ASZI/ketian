<template>
  <div class="seven" v-if="resData">
    <!-- 上两图 -->
    <div class="seven-nc">
     

      <div class="xzxd">
        <van-image  :src="resData.xzxd" @click="$router.push('login')"/>
      </div>
      <div class="nbjx"><van-image   :src="resData.nbjx" @click="$router.push('calendar')"/></div>
    </div>
    <!-- 4图 -->
    <div class="st">
      <div class="nbcp"><van-image :src="resData.nbcp" @click="$router.push('order')" /></div>
      <div class="nhs"><van-image :src="resData.nbhs" @click="$router.push('bill')"/></div>
      <div class="yhu"><van-image :src="resData.nbyh" @click="$router.push('coupon')"/></div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    resData: Object,
  },

};

</script>



<style lang="scss" scoped>
@import "~@/assets/scss/home";
</style>
