<template>
  <div class="logos">
    <div class="logo"><van-image :src="logo" /></div>
  </div>
</template>

<script>
  export default {
    props: {
      logo:String
    },
  }
</script>

<style lang="scss" scoped>

// logo
.logos {
  display: flex;
  justify-content: center;
  .logo {
    @extend .logos;
    border-radius: 100%;
    margin-top: 50px;
    width: 400px;
    height: 400px;
  }
}
</style>