<template>
	<div>
		<van-nav-bar
			:title="title" 
			:left-arrow="true"
			:right-text="rightText"
			
			:border="false"
			@click-left="prev"
			@click-right="clickRight">
		</van-nav-bar>
	</div>
</template>

<script>
	export default {
		props: {
			title:{
				type:String,
				default:'可用优惠券'
			},
			rightText: {
				type: String,
			},
			
			
		},
		methods: {
			// 返回
			prev() {
				this.$router.go(-1);
			},
			// click-right
			clickRight(){
				this.$emit('clickRight')
			}
			//查看无效优惠券
			// invalid() {
			// 	this.$router.push('invalid');
			// },
			
		},
	}
</script>

<style lang="scss" scoped>
::v-deep .van-nav-bar{
	background-color: pink;
}
::v-deep .van-nav-bar .van-icon {
    color: blue;
}
::v-deep .van-nav-bar__text{
	color:orange;
}
</style>