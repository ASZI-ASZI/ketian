<template>
	<div>
		<van-button v-for="(item,index) in label.list"
		    :key="index"
			round 
			:color="label.selected == index ? '#6D86C4':''"
			@click="rlChecked(index)">
			<span class="title">
				{{item.name}}
			</span>	
		</van-button>
	</div>
</template>

<script>
	export default {
		props: {label: Object},
		data() {
			return {}
		},
		methods: {
			// 容量,模式
			rlChecked(index){
				this.$emit('update:selected',index)
			},
			
		},
	}
</script>

<style lang="scss" scoped>
// 容量
.van-button{
	height: 60px;
	width: 160px;
	line-height: 60px;
	margin-left: 20px;
	margin-bottom: 10px;
	margin-top: 10px;
	font-size: 18px;
		
}
</style>