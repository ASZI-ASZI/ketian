<template>
	<div>
		<van-nav-bar :border="false" :title="title" @click-right="show">
			<template #right>
				<van-icon name="clear" color="#000" size="20" />
			</template>
		</van-nav-bar>
	</div>
</template>

<script>
export default {
	props: {
		title:String
	},
	methods: {
		show() {
			this.$emit('show')
		}
	},
}
</script>

<style scoped>

</style>