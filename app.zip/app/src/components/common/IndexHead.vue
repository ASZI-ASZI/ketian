<template>
	<div>
		<div class="cell">
			<span>{{title}}</span>
			<div class="cell_c" @click="change">
				<van-icon :name="nIcon" :color="color"/>
				<span>{{value}}</span>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		title:{
			type:String,
			default:'新鲜事'
		},
		// 图标
		nIcon:String,
		// 值
		value:String,
		// 图标颜色
		color:{
			type:String,
			default: '#6e6e6e'
		}
	},
	// 动态获取图标颜色
	computed: {
		getColor() {
			return `color: ${this.color}`
		}
	},
	methods: {
		change() {
			this.$emit('change')
		}
	},
}
</script>

<style lang="scss" scoped>

.cell{
	
	width: 710px;
	// background-color: green;
	font-weight: bold;
	height: 36px;
	line-height: 36px;
	font-size: 30px;
	display: flex;
	justify-content: space-between;
	
	.cell_c{
		color: #6d86c4;
		display: flex;
		align-items: center;
		.van-icon{
			margin-right: 10px;
		}
	}
}
</style>