<template>
	<div>
		<!-- tabBar -->
		<van-tabbar route v-if='$route.meta.showTab'
			:v-model="active"  
			active-color="#333999" 
			inactive-color="#000">
			<van-tabbar-item replace 
			v-for="(item, index) in tabBar" :key="index" 
			:icon="item.icon" 
			:to="item.path" 
			:badge="item.id == 4 && cartCount > 0 ?  cartCount :''">
				{{ item.title }}
			</van-tabbar-item>
		</van-tabbar>
	</div>
</template>

<script>
import {mapGetters} from 'vuex'
export default {
	props: {
		active: {
			type: String,
			default: 'home'
		},
		tabBar: Array,
	},
	computed: {
		...mapGetters([
			'cartCount',
		])
	},
	
};
</script>

<style lang="scss" scoped>
	
</style>
