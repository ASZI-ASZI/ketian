<template>
	<div class="content">
		<van-cell is-link 
		:class="pay.value == 'alipay' ? 'alipay':'' || pay.value == 'wxpay' ? 'wxpay':'' || pay.value == 'nbqb' ? 'nbqb':''" 
		:icon="pay.icon" 
		:title="pay.title" 
		@click="show" />
		<van-popup v-model="pay.isShow" 
		closeable  close-icon-position="top-right"
		get-container=".content">
		<div class="title">支付中心</div>
			<van-radio-group v-model="pay.radio" >
				<van-cell-group>
					<van-cell 
						:icon="item.icon"
						v-for="(item, index) in resData" 
						:key="index"
						:title="item.title" 
						clickable 
						:class="index == 1 ? 'wxpay':'nbqb' && index == 0 ? 'nbqb':'alipay' && index == 2 ? 'alipay':''"
						@click="onSelect(item)">
						
					  <template #right-icon>
						<small style="color: #aeaeae;" v-if="item.value == 'nbqb'">
							{{item.balance <= 0 ? '余额不足': '￥'+item.balance}}
						</small>
						<van-radio v-else checked-color="#6d86c4" :name="item.name" />
					  </template>
					</van-cell>
				</van-cell-group>
			</van-radio-group>
		</van-popup>

	</div>
</template>

<script>
export default {
	props: {
		resData: Array,
		pay:Object,
		// 默认支付
		radio:{
			type:Number,
			default:3
		},
		// 弹框默认关闭
		isShow:{
			type:Boolean,
			default:false
		}
	},
	
	methods: {
		onSelect(item) {
			this.$emit('onSelect',item)
		},
		show(){
			this.$emit('show')
		}
	}
};
</script>

<style lang="scss" scoped>
.wxpay{
		font-size: 30px;
		//支付图标
		.van-cell__left-icon {
		   display: flex;
		   align-items: center;
		   justify-content: center;
		   font-size: 50px;
		   color: #00ce00;
		}
		
	}
.alipay{
		font-size: 30px;
		//支付图标
		.van-cell__left-icon {
		   display: flex;
		   align-items: center;
		   justify-content: center;
		   font-size: 50px;
		    color: #009fe8;
		}
		
	}
.nbqb{
		font-size: 30px;
		//支付图标
		.van-cell__left-icon {
		   display: flex;
		   align-items: center;
		   justify-content: center;
		   font-size: 50px;
		    color: #2e7dd5;
		}
		
	}
.content {
	
	margin: 20px 20px 40px 20px;
	border-radius: 30px;
	font-size: 30px;
	width: 710px;
	.van-cell{
		border-radius: 10px;
	}
	.title{
		display: flex;
		align-items: center;
		justify-content: center;
		height: 104px;
		background-color: #f5f5f5;
		
	}
	// 弹框
	.van-popup--center {
		top: 80%;
		-webkit-transform: translate3d(-50%, -50%, 0);
		transform: translate3d(-50%, -50%, 0);
	}
	.van-popup {
		position: fixed;
		height: 586px;
		width: 710px;
		border-radius: 20px;
		overflow-y: auto;
		background-color: #fff;
	}
}
</style>
