<template>
	<!-- 价格、购物按钮 -->
	<div class="pb">
		<div class="price">
			<div class="Sprice">￥{{ Sprice }}</div>
			<div class="Oprice">￥{{ Oprice }}</div>
		</div>
		
		<div class="button" v-if="isShow">
			<!-- 加减控件 -->
			<transition name="reduce">
				<span class="icon iconfont icon-jianshao"
				 @click="reduce"  v-show="numb.count > 0">
				</span>
			</transition>
			<span class="price" v-show="numb.count > 0">{{numb.count}}</span>
			<span class="icon iconfont icon-zengjia" @click="add" />
			
		</div>
		
	</div>
</template>

<script>
import Vue from 'vue'
export default {
	
	props: {
		Sprice: {
			type: Number,
			default: 0
		},
		Oprice: {
			type: Number,
			default: 0
		},
		isShow: {
			type: Boolean,
			default: true
		},
		numb:Object
	},

	created() {
		
	},
	methods: {
		// 减少
		reduce(){
			if(this.numb.count > 0){
				this.numb.count--
			}
		},
		// 增加
		add() {
			if(!this.numb.count){
				Vue.set(this.numb,'count',1)
			}else{
				this.numb.count++
			}
		},
		
		
	},

};
</script>

<style lang="scss" scoped>
// 价格、购物按钮 
.pb {
	display: flex;
	justify-content: space-between;
	align-items: center;
	// margin: 0 10px 0 10px;
	//价格
	.price {
		display: flex;
		align-items: center;
		.Sprice {
			font-weight: bold;
			color: #ec5100;
			font-size: 30px;
		}
		.Oprice {
			margin-left: 10px;
			font-size: 20px;
			color: #aeaeae;
			text-decoration: line-through;
		}
	}
	// 添加按钮
	.button {
		display: flex;
		align-items: center;
		height: 48px;
		.icon {
			color: #6d86c4;
			background-color: #fff;
			font-size: 54px;
			border-radius: 50%;
		}
		.price {
			padding: 10px;
			font-size: 30px;
		}
		
		// 过渡动画
		.reduce-enter-active, .reduce-leave-active {
		  transition: all .4s ease-out;
		}
		
		.reduce-enter, .reduce-leave-to{
		  transform: translateX(20px)rotate(180deg);
		  opacity: 0;
		}
		
	}
	
	
}
// 引入阿里icon
@import "../../assets/icon/iconfont.css"
</style>
