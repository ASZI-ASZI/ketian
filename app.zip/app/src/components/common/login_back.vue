<template>
	<div class="login_header">
		<div class="icon">
			<van-icon @click="prev" name="arrow-left" size="30" />
		</div>
		<div class="text">{{text}}</div>
		<div class="wx">
			<span v-if="show" @click="invalid">查看无效券</span>
		</div>
	</div>
</template>

<script>
	export default {
		props: {
			text:{
				type:String,
				default:'登录'
			},
			show:{
				type:Boolean,
				default:false
			}
		},
		methods:{
			// 返回上一页
			prev(){
				this.$emit('prev')
			},
			//查看无效优惠券
			invalid(){
				this.$emit('invalid')
			}
		
			
		}
	}
</script>

<style lang="scss" scoped>
//返回、登录
.login_header {
	// background-color: grey;
	height: 50px;
	text-align: center;
	width:710px;
	margin: 20px 20px 0 20px;
	font-size: 34px;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 30px;
	
}
</style>