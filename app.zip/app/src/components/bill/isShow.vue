<template>
	<div>
		<transition name="van-fade">
			<div v-if="isShow" class="list_desc">
				
				<c-header :title="listIndex.name" @show="show"></c-header>
				
				<!-- 图片 -->
				<div class="img_wrap">
					<van-image width="8rem" height="10rem" :src="img_wrap" />
					<span>您还没有发票抬头</span>
				</div>
				<!-- 添加按钮 -->
				<div class="button" v-if="listIndex.id == 6">
					<van-button round block color="#6d86c4">添加发票抬头</van-button>
				</div>
				<div class="buttons" v-else> 如需查询之前的订单信息，请联系客服。 </div>
			</div>
		</transition>
	</div>
</template>

<script>

import CHeader from '../common/header.vue'
export default {
	components: {
		CHeader
	},
	props: {
		isShow:Boolean,
		listIndex:Object,
		img_wrap:String
	},
	methods: {
		show() {
			this.$emit('show')
		}
	},
}
</script>

<style lang="scss" scoped>
// 列表内容详情
.list_desc {
	position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	background-color: #f5f5f5;
	z-index: 9998;
	::v-deep .van-nav-bar {
		background-color: #f5f5f5;
	}
	// 图片
	.img_wrap {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 80%;
		flex-direction: column;
		&>span{
			color: #6e6e6e;
			font-size: 30px;
		}
		
	}
	// 按钮
	.button{
		position: fixed;
		bottom: 0;
		left: 20px;
		right: 20px;
		width: 710px;
		height: 123px;
		z-index: 9999;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.buttons{
		@extend .button;
		color: #6e6e6e;
		font-size: 30px;
	}
}
</style>