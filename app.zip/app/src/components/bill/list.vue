<template>
	<div>
		<div class="list" v-for="(item, index) in resData" :key="index">
			<div class="list_content" v-for="(items, indexs) in item.data" :key="indexs" 
			@click="show(items)">
				<span>{{ items.name }}</span>
				<van-icon name="arrow" color="#aeaeae"></van-icon>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		resData:Array
	},
	methods: {
		show(items) {
			this.$emit('show',items)
		}
	},
}
</script>

<style lang="scss" scoped>
//list
.list {
	margin: 0 20px 20px 20px;
	height: 100%;
	width: 710px;
	border-radius: 10px;
	background-color: white;
	display: flex;
	flex-direction: column;
	font-size: 30px;
	.list_content {
		display: flex;
		justify-content: space-between;
		margin: 30px 20px 30px 20px;
		height: 30px;
		line-height: 30px;
		width: 670px;
		// background-color: green;
	}
}
</style>