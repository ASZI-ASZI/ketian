<template>
	<div>
		<transition name="van-fade">
		  <div class="explain" v-if="explain">
		  	<c-header title="发票说明" @show="clickRight"/>
		  	<div class="content">
		  		<div class="desc">
					1、通过银行卡（包括信用卡借记卡）和网上支付平台（包括支付宝和微信支付）
					支付的费用，可用于开具发票。以代金券、优惠券或营销活动支付或充低的费用，
					恕不能开具发票。<br/><br/>
					2、您可在【我的】-【发票管理】中提交开票需求。<br/><br/>
					3、我们开具经主管税务机关批准的增值税电子普通发票。根据税务法律法规规定，
					如需纸质发票的客户可以自行打印增值电子普通发票的PDF版式文件。增值税电子
					普通发票打印后，其法律效力、基本有途、基本使用规定等与税务监制的增值税普通
					发票相同。<br/><br/>
					4、如果购买方为企业的，除发票抬头填写全称外，还需提供准确的纳税人识别号或统一
					社会信用代码，以免无法正常报销。
					
				</div>
		  	</div>
		  </div>
		</transition>
	</div>
</template>

<script>
import CHeader from '../common/header.vue'
export default {
	components: {
		CHeader
	},
	props: {
		explain:Boolean,
		
	},
	methods: {
		clickRight() {
			this.$emit('clickRight')
		}
	},
}
</script>

<style lang="scss" scoped>
// 发票说明
.explain{
	position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	background-color: #f5f5f5;
	z-index: 9998;
	font-size: 30px;
	::v-deep .van-nav-bar {
		background-color: #f5f5f5;
	}
	.desc{
		margin: 10px 20px;
		color: #6e6e6e;
		line-height: 50px;
		display: flex;
	}
}
</style>