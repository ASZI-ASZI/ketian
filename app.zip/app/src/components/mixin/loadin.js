export default{
	data(){
		return { 
			beforeReady:true
		}
	},
	mounted(){
		setTimeout(() => {
			this.beforeReady = false
		},500)
	}
	
}