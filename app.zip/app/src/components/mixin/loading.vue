<template>
	<div>
		<van-loading type="spinner" color="#1989fa"> </van-loading>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style lang="scss" scoped>
.van-loading{
	position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	background-color: white;
	z-index: 9999;
}
</style>