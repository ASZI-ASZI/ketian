<template>
	<div class="lbt">
		<van-swipe 
		:autoplay="3000" 
		indicator-color="white" 
	
		>
		 <!-- :indicator-color="`#3d44a8`" -->
		  <van-swipe-item v-for="(item,index) in resData" :key="index">
		    <van-image  class="img" :src="item.img" />
		  </van-swipe-item>
		</van-swipe>
	</div>
</template>

<script>
	export default {
		props: {
			resData:Array
		},
	}
</script>

<style lang="scss" scoped>
// 轮播图
.lbt{
	display: flex;
	margin: -350px 20px 20px 20px ;
	height: 254px;
	border-radius: 10px;
	// background-color: #f7dfde;
	.van-swipe {
		height: 254px;
		width: 710px;
		border-radius: 10px;
		// margin-top: 64px;
	}
	.van-swipe-item {
		width: 710px;
		height: 254px;
		border-radius: 10px;
		color: #fff;
		font-size: 15px;
		text-align: center;
		& > img {
			max-height: 100%;
			max-width: 100%;
		}
	}
}
</style>