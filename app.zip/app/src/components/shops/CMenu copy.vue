<template>
	<div class="menu">
		<circle-menu
			type="left"
			:number='4' 
			animate="animated jello"
			circle
		:colors="[ '#6d86c4', '#6d86c4', '#6d86c4', '#6d86c4', '#6d86c4']">
		<button class="button" slot="item_btn">
			<van-icon color="#6d86c4" name="smile" size="34" />
		</button>
			<router-link
				v-for="item in resData" 
				:key="item.name"
				class="text" 
				:to="item.path" 
				:slot="item.slot">
				{{item.title}}
			</router-link>
		</circle-menu>
	</div>
</template>

<script>
	// 圆形菜单
	import CircleMenu from 'vue-circle-menu'
	export default {
		components: {
			CircleMenu
		},
		props:{
			resData:Array
		}
	}
</script>

<style lang="scss" scoped>
// circle-menu
.menu{
	position: fixed;
	left: 40px;
	bottom: 180px;
	z-index: 9997;
	font-size: 26px;
	
	.van-icon{
		position: absolute;
		left: 0;
		bottom: 0;
		right: 0;
		top: 0;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.text{
		color: white;
		font-weight: bolder;
	}
	::v-deep .oy-menu-btn{
	    width: 60px;
	    height: 60px;
	    line-height: 60px;
		display: flex;
	    border: none;
	    text-align: center;
		color: red;
		.button{
			width: 60px!important;
			height: 60px!important;
			line-height: 60px!important;
			border: none;
			border-radius: 50%;
			position: absolute;
			left: 0;
			right: 0;
			top: 0;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		
		
	}
	
	
}
</style>