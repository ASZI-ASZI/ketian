<template>
	<div class="total">
		<div class="left">
			<van-icon
				:class="{ active: totalNum > 0 }"
				size="26px"
				:color="totalPrice > 0 ? '#fff' : '' "
				name="shopping-cart"
				:badge="totalNum > 0 ? totalNum : '' "
				@click="totalNum > 0 ? median=true :'' "
			/>
			<span>￥{{ totalPrice }}</span>
			<span class="by">全场商品下单免费配送</span>
		</div>
		<div class="right">
			<van-button size="normal" 
				:disabled="totalPrice > 0 ? false : true" 
				:color="totalPrice > 0 ? '#f05821' : '#333'"
				@click="total"
			>{{ settle }}</van-button>
		</div>
		<!-- 购物车弹框 -->
		<van-action-sheet 
		    v-show="hide" 
			v-model="median" title="购物车" @cancel="cancel">
			<!-- 内容  -->
			<div class="content">
				<!-- 循环的列表 -->
				<van-cell center v-for="(item, index) in cartData" :key="index" :title="item.title " :value="item.sku" >
				 
					<com-price
					 :numb="item" 
					 :Sprice="item.Sprice*item.count" 
					 :Oprice="item.Oprice" />
				 </van-cell>
				 
				
			</div>
		</van-action-sheet>
		
	</div>
</template>

<script>
// price
import ComPrice from '@/components/common/price.vue';

export default {
	components: {ComPrice},
	props: {
		totalNum: {
			type: Number,
		},
		totalPrice: {
			type: Number
		},
		settle: {
			type: String
		},
		cartData:Array
	},
	data() {
		return {
			median: false,
		};
	},
	computed: {
		// 隐藏购物车弹框
		hide() {
			if(this.totalNum == 0){
				this.median = false
			}
			return this.median
		}
	},
	methods: {
		// 清空
		cancel() {
			this.median = true;
			this.$dialog
				.confirm({
					message: '客官，您确定清空购物车吗?'
				})
				.then(() => {
					this.median = false;
					// 清空
					this.cartData.forEach(item => {
						item.count = 0
					})
				})
				.catch(() => {this.median = true;});
		},
		// 立即购买
		total(){
			this.$toast.success('立即购买')
			this.$router.push({path:'/affirm'});
		}
	}
};
</script>

<style lang="scss" scoped>
//弹框
.content {
	padding: 10px 10px 160px;
	max-height: 400px;
	
	//header
	.van-action-sheet__header {
		font-weight: bold;
		font-size: 30px;
		display: flex;
		height: 80px;
		line-height: 80px;
		width: 100%;
		background-color: #f3f5f7;
		padding-left: 30px;
		border-top-left-radius: 20px;
		border-top-right-radius: 20px;
		
	}
	
	
}
// 合计
@import '~@/assets/scss/total';
</style>
