<template>
	<div class="box">
		<!-- 商品、菜单 -->
		<div class="sp_cd">
			<!-- 左菜单 -->
			<div class="left" ref="left">
				<ul>
					<li  v-for="(item, index) in resData" :key="index"
					@click="active(index, $event)"
					:class="{ active : activeIndex == index }">
						<span class="left-item">{{ item.name }}</span>
						<span 
						v-show="subtotal(item.content) > 0"
						:class="subtotal(item.content) > 0 ? 'van-info' : ''"
						>{{subtotal(item.content)}}</span>
					</li>
				</ul>
			</div>
			<!-- 右商品 -->
			<div class="right" ref="right">
				<ul>
					<li class="shop_content right-item-hook" 
						v-for="val in resData" :key="val.name">	
						<!-- 商品对应标题 -->
						<span class="title">{{ val.name }}</span>
						<!-- 商品循环 -->
						<div class="img_shop" v-for="(item, indexs) in val.content" :key="indexs" >
							<van-image :src="item.img" @click="toDetails(item)" />
							<div style="width: 100%;">
								<div class="shop_desc" @click="toDetails(item)">
									<span class="shop_t">{{ item.title }}</span>
									<small class="shop_d">{{ item.sub_title }}</small>
									<small class="shop_d">默认:{{ item.sku }}</small>
								</div>
								<com-price class="com-price" :numb="item" :Sprice="item.Sprice" :Oprice="item.Oprice" />
								
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
		
	</div>
</template>

<script>
// 滑动
import BScroll from 'better-scroll';
// price
import ComPrice from '@/components/common/price.vue';

export default {
	components: { ComPrice},
	props:{
		resData:Array,
	},
	
	data() {
		return {
			//实时获取当前y轴的高度
			scrollY: 0,
			//存放每一个类的初始位置
			listHeight:[],
			clickEvent: false,
			
		};
	},
	
	methods: {
		// 商品详情
		toDetails(item){
			this.$emit('toDetails',item)
		},
		//实例化滚动
		initScroll(){
			this.left = new BScroll(this.$refs.left,{
				click:true
			})
			this.right = new BScroll(this.$refs.right,{
				//探针的效果，实时获取滚动高度
				click:true,
				probeType:3
			})
			// 1、监听滚动位置
			this.right.on('scroll', pos => {
				this.scrollY = Math.abs(Math.round(pos.y))+80;
			});
			
			
		},
		// 2、获取每一区域距离顶部的高度
		getHeight(){
			let rightItems = this.$refs.right.getElementsByClassName('right-item-hook');
			let height = 0;
			this.listHeight.push(height);
			for (let i = 0; i < rightItems.length; i++) {
				let item = rightItems[i];
				height += item.clientHeight;
				this.listHeight.push(height);
			}
		},
		
		// 菜单
		active(index,event){
			this.clickEvent = true
			//在better-scroll的派发事件的event和普通浏览器的点击事件event有个属性区别_constructed
			//浏览器原生点击事件没有_constructed所以当时浏览器监听到该属性的时候return掉
			if(!event._constructed){
				return 
			}else{
				let rightItems = this.$refs.right.getElementsByClassName('right-item-hook');
				let el = rightItems[index];
				this.right.scrollToElement(el, 300);
			}
		},
		//计算分类的数量
		subtotal(content){
			let num = 0
			content.forEach(item => {
				if(item.count >  0){
					num+=item.count
				}
			})
			return num
		}
	},
	mounted() {
		this.$nextTick(() => {
			this.initScroll()
			this.getHeight()
		})
	},
	
	computed: {
		// 设置（index）左右联动
		activeIndex() {
			for(let i = 0; i< this.listHeight.length; i++){
				let height = this.listHeight[i]
				let height2 = this.listHeight[i+1]
				if(!height2 || (this.scrollY >= height && this.scrollY < height2)){
					return i
				}
			}
			//如果this.listHeight没有的话，就返回0
			return 0
		},
		
		
	},
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/shopsBscroll'
</style>
