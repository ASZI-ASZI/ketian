<template>
  <div class="cell">
    <div class="cell_content">
      <!-- 图标、地址 -->
      <div class="icon_add">
        <van-icon name="location-o" size="24" color="#6d6d6d" />
        <template v-if="path">
          <div v-if="radio === 'ps'" class="addinfo" @click="addres">
            <span>{{ path.addressDetail }}</span>
            <div class="small">
              <small>{{ path.tel }}</small>
              <small class="name">{{ path.name }}</small>
            </div>
          </div>
          <!-- 自取(定位当前最近店铺地址) -->
          <div v-if="radio === 'zq'">
            <div
              class="addinfo"
              v-for="(zq, zqIndex) in zqList"
              :key="zqIndex"
              @click="storeAction"
            >
              <span>{{ zq.title }}</span>
              <div class="small">
                <small>{{ zq.label }}</small>
              </div>
            </div>
          </div>
        </template>

        <!-- 无设置默认地址时 -->
        <template v-else>
          <div v-if="radio === 'ps'" @click="addres">请选择收货地址</div>
          <div
            v-else
            class="addinfo"
            v-for="(zq, zqIndex) in zqList"
            :key="zqIndex"
          >
            <span>{{ zq.title }}</span>
            <div class="small">
              <small>{{ zq.label }}</small>
            </div>
          </div>
        </template>
      </div>
      <!-- 选项 -->
      <div class="xx">
        <van-radio-group v-model="radio" direction="horizontal">
          <van-radio
            v-for="(item, index) in radioData"
            :key="index"
            checked-color="#6d86c4"
            icon-size="20px"
            :name="item.name"
            @click="change(item)"
          >
            {{ item.label }}
          </van-radio>
        </van-radio-group>
      </div>
    </div>
  </div>
</template>

<script>
// vuex
import { mapGetters } from "vuex";

export default {
  props: {
    // 按钮
    radioData: Array,
    zqList: Array,
  },
  data() {
    return {
      path: false,
      radio: "ps",
    };
  },

  created() {
    // 没有设置默认地址(显示请选择地址)
    if (this.defaultAction.length) {
      this.path = this.defaultAction[0];
    }
    this.get();
  },

  computed: {
    ...mapGetters(["defaultAction"]),
  },
  methods: {
    // 方式
    change(item) {
      this.radio = item.name;
    },
    // 跳转收件地址
    addres() {
      this.$router.push({
        path: "/address",
        query: { type: "choose" },
      });
    },
    // 自取(定位当前最近店铺地址)
    storeAction() {
      this.$router.push({
        path: "store",
      });
    },
    // 接收广播事件,接收数据
    get() {
      this.$root.bus.$on("choosAction", (val) => {
        this.path = val;
      });
    },
  },
  // 移除
  beforeDestroy() {
    this.$root.bus.$off("choosAction", this.get());
  },
};
</script>

<style lang="scss" scoped>
// 地址、按钮
.cell {
  margin: 0px 20px 20px 20px;
  height: 128px;
  width: 710px;
  border-radius: 10px;
  background-color: white;
  display: flex;
  font-size: 30px;
  flex-direction: column;
  // content
  .cell_content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px 10px;
    height: 108px;
    // background-color: grey;
    .icon_add {
      display: flex;
      align-items: center;
      //addinfo
      .addinfo {
        display: flex;
        flex-direction: column;
        margin-left: 10px;
        width: 340px;
        & > span {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .small {
          color: #6d6d6d;
          .name {
            margin-left: 10px;
          }
        }
      }
    }
  }
}
</style>