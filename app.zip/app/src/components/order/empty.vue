<template>
	<div class="ct">
		
		<div class="empty">
			<van-empty class="custom-image" :image="img" description="不过节吗!什么都没有哦？">
				<van-button round color="#6d86c4" class="bottom-button" @click="gyg">去逛一逛吧</van-button>
			</van-empty>
		</div>
	</div>
</template>

<script>
export default {
	data() {
		return {
			img: require('../../assets/img/order.png')
		};
	},
	methods:{
		gyg(){
			this.$router.push({path:'/shops'})
		}
	}
	
};
</script>

<style lang="scss" scoped>
// 空
.ct{
	// position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	height: 70vh;
	
	display: flex;
	align-items: center;
	justify-content: center;
	
	.empty {
		
		::v-deep .van-empty__image {
			width: 460px;
			height: 500px;
		}
		::v-deep .van-empty__description {
			color: #000;
			font-size: 30px;
		}
		.bottom-button {
			width: 300px;
			height: 80px;
		}
	}
	
}

</style>
