<template>
	<div>
		<div class="content" v-for="(item, index) in resData" :key="index">
			<div class="list" >
				<div @click="show(item)">
					<div class="list_head">
						<div class="title">
							<van-tag type="warning">{{ item.title == 1 ? '配送' : '自提' }}</van-tag>
							订单:{{ item.order_number }}
						</div>
						<div :class="item.value == 0 ? 'value' : '' || item.value == 1 ? 'value' : ''">
						{{ item.value == 0 ? '准备中' : '' || item.value == 1 ? '配送中' : '完成'  }}
						</div>
					</div>
					<van-divider />
					<!-- 配送 -->
					<div class="list_c">
						<span v-if="item.title == 2">{{ item.location }}(NO.{{ item.no }})</span>
						<span v-if="item.title == 1">{{ item.site }}</span>
						<span class="time">{{ item.time }}</span>
					</div>
					<!-- 单个商品 -->
					<div class="shop" v-for="(items, indexs) in item.oreder_item" :key="indexs">
						<span>{{ items.name }}</span>
						<span class="num">X{{ items.nubmer }}</span>
						<span>￥{{ items.price }}</span>
					</div>
					
				</div>
				<!-- 合计 -->
				<div class="price">
					<span class="num">合计:￥40</span>
					<div class="button">
						<van-button plain round type="info" size="small" color="#aeaeae"
						@click.stop="zlyd">再来一单</van-button>
						<van-button plain round type="info" size="small" color="#6d86c4"
						@click.stop="qpj">去评价</van-button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		resData: Array,
	},
	methods: {
		// 显示
		show(item) {
			this.$emit('show',item)
		},
		// 再来一单
		zlyd(){
			this.$toast('再来一单')
		},
		// 去评价
		qpj(){
			this.$toast('去评价')
		}
	},
};
</script>

<style lang="scss" scoped>
	// content
	.content{
		display: flex;
		margin: 20px 20px;
		// height: 440px;
		height: 100%;
		width: 710px;
		background-color: white;
		border-radius: 10px;
		font-size: 30px;
		.list{
			margin: 20px 20px;
			// height: 400px;
			height: 100%;
			width: 690px;
			// background-color: seagreen; 
			.list_head{
				display: flex;
				justify-content: space-between;
				color: #131313;
				.value{color: #6d86c4;}
			}
			.list_c{
				@extend .list_head;
				color: #000;
				// font-weight: bold;
				.time{color: #b9b9b9;font-weight: normal;}
			}
			.shop{
				margin-top: 20px;
				margin-bottom: 20px;
				@extend .list_c;
				
				.num{margin-left: 10px;color: #b9b9b9;}
				
			}
			.price{
				@extend .list_c;
				font-weight: bold;
				.num{
					color: #ff2712;
				}
				.button{
					.van-button{
						width: 170px;
						margin-left: 10px;
					}
				}
			}
			
		}
		 
	}
</style>
