<template>
	<div>
		<van-cell-group >
			<van-cell :title="title" value="来了" @click="check" />
		</van-cell-group>
	</div>
</template>

<script>
	export default {
		props: {
			title:String
		},
		methods: {
			check() {
				this.$emit('update:title','hello')
			}
		},
	}
</script>

<style scoped>

</style>