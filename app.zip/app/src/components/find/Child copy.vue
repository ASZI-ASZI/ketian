<template>
	<div>
		<p class="child" @click="change">{{ value }}</p>
	</div>
</template>
<script>
export default {
	model: {
		//添加了model方法，用于接收v-model传递的参数
		//父组件中变量的传递
		prop: 'value',
		//事件传递
		event: 'changeChild'
	},
	props: {
		value: {
			type: String
		}
	},
	data() {
		return {
			childText: this.value //定义自己的变量childText
		};
	},
	methods: {
		change() {
			this.childText = '我是子组件里的文字';
		}
	},
	watch: {
		value(newtext) {
			//使用父组件中变量名为函数名，监听value的变化，如果变化，则改变子组件中的值
			this.childText = newtext;
		},
		childText(newtext) {
			//监听子组件中childText变化，如果变化，则通知父组件，进行更新
			this.$emit('changeChild', newtext);
		}
	}
};
</script>
<style lang="scss" scoped>
.child{
	background-color: dimgray;
	color: white;
	border-radius: 10px;
	font-size: 30px;
	width: 150px;
	height: 80px;
	line-height: 80px;
	margin: 5px 5px;
}
</style>
