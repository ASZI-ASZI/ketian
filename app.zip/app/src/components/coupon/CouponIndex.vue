<template>
	<div>
		<div class="yhj" v-for="(item, index) in resData" :key="index">
			<!-- 优惠券列表 -->
			<div class="coupon">
				<div class="content">
					<span class="title">{{ item.title }}</span>
					<span class="time">{{ item.time }}</span>
				</div>
				<div class="zk">
					{{ item.zk }}
					<small>折</small>
				</div>
				<!-- 立即使用按钮 -->
				<div class="button" v-if="isShow"><van-button color="orange" round size="mini" @click="ljss">立即使用</van-button></div>
			</div>
			<!-- 使用规则 -->
			<div class="sygz">
				<!-- 使用规则内容 -->
				<div class="sygznr">
					<van-collapse v-model="ssgz">
						<van-collapse-item title="使用规则" :name="item.name" icon="shop-o">
							<div class="jgsm_descs van-multi-ellipsis--l2">{{ item.desc }}</div>
							<div class="jgsm_descs van-multi-ellipsis--l2">{{ item.desc1 }}</div>
							<div class="jgsm_descs van-multi-ellipsis--l2">{{ item.desc2 }}</div>
						</van-collapse-item>
					</van-collapse>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		resData: Array,
		isShow: {
			type: Boolean,
			default: true
		}
	},
	data() {
		return {
			// 使用规则内容
			ssgz: []
		};
	},
	methods: {
		//加载
		onLoad() {
			this.$emit('onLoad');
		},

		// 立即使用
		ljss() {
			this.$emit('ljss');
		}
	}
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/couponIndex';
</style>
