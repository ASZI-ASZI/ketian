<template>
	<div class="tjdd">
		<div class="tjdd_content">
			<!-- 标题、价格、 步进器-->
			<div class="tjdd_header">
				<div class="cpgg_header">
					<div class="prices" v-for="(item,index) in resData" :key="index">
						<com-price :Sprice="item.Sprice" :Oprice="item.Oprice" :isShow="false"> </com-price>
						<span class="cpgg_title">{{item.cpgg_title}}</span>
					</div>
					
				</div>
				<!-- button Stepper 步进器-->
				<!-- <div class="buttons">
					<van-stepper v-model="resData.value" theme="round" button-size="26" disable-input />
				</div> -->
			</div>	
			<!-- 三个按钮 -->
			<div class="tjdd_button">
				<van-button v-for="(item,index) in buts" :key="index"
					 round 
					 :color="isColor== item.id ? '#6D86C4':''"
					 @click="checked(item)">
				{{item.title}}		
				</van-button>
				
			</div>
		</div>
	</div>
</template>

<script>
	// price
	import ComPrice from '@/components/common/price.vue'
	export default {
		components: {ComPrice},
		props: {
			resData: Array,
			//三个按钮
			buts:Array
		},
		data(){
			return{
				// 默认选中立加入购物车
				isColor: 3, 
			}
		},
		methods: {
			// 按钮当前选项
			checked(item){
				this.isColor = item.id
				this.$router.push(item.url)
			}
		},
	}
</script>

<style lang="scss" scoped>
	//提交订单
	.tjdd{
		position: fixed;
		left: 0px;
		bottom: 0px;
		width: 750px;
		height: 198px;
		background-color: #ffffff;
		z-index: 9999;
		.tjdd_content{
			display: flex;
			flex-direction: column;
			margin: 30px 20px 18px 20px;
			height: 150px;
			// background-color: grey;
			// 标题、价格、步进器
			.tjdd_header{
				display: flex;
				justify-content: space-between;
				height: 70px;
				width: 100%;
				// Stepper 步进器
				.buttons {
					::v-deep .van-stepper__minus {
						color: #6d86c4;
						background-color: #fff;
						border: 1px solid #6d86c4;
					}
				
					::v-deep .van-stepper__plus {
						color: #fff;
						background-color: #6d86c4;
					}
				
				}
				.prices{
					font-size: 20px;
					.cpgg_title{margin-left: 10px;}
				}
			}
			//圆形按钮
			.tjdd_button{
				display: flex;
				justify-content: space-around;
				height: 60px;
				width: 710px;
				margin-top: 20px;
				// background-color: green;
				.van-button{
					font-size: 26px;
					color: #6D86C4;
					border: 1px solid #6D86C4;
					height: 60px;
					width: 220px;
				}
				
				
			}
		}
		
	}
	
</style>