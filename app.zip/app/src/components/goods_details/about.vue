<template>
	<!-- 收藏、返回上一级 -->
	<div class="about">
		<div class="top">
			<!-- 默认 -->
			<div class="tops">
				<!-- 收藏 -->
				<div>
					<van-sticky><van-icon size="18" :name="isSelected ? 'like' : 'like-o'" /></van-sticky>
				</div>
				<!-- 返回上一级 -->
				<div>
					<van-sticky><van-icon size="18" name="cross" /></van-sticky>
				</div>
			</div>
			<!-- 滑动后 -->
			<div class="back-fixed" :style="isOpacity">
				<!-- 收藏 -->
				<div>
					<van-sticky><van-icon @click="collect" size="18" :name="isSelected ? 'like' : 'like-o'" /></van-sticky>
				</div>
				<!-- 中间 -->
				<div class="van-ellipsis">商品详情</div>
				<!-- 返回上一级 -->
				<div>
					<van-sticky><van-icon @click="prev" size="18" name="cross" /></van-sticky>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		isSelected: {
			type: Boolean,
			default: false
		},
		isOpacity:Object
	},
	methods: {
		// 收藏与取消收藏
		collect(){
			this.$emit('collect')
		},
		// 返回上一级
		prev() {
			this.$emit('prev')
		}
	},
};
</script>

<style lang="scss" scoped>
.about {
	width: 750px;
	height: 100%;
	// 收藏、返回上一级
	.top {
		position: fixed;
		left: 0;
		top: 0;
		width: 750px;
		height: 86px;
		z-index: 9999;
		// 默认
		.tops {
			display: flex;
			justify-content: space-between;
			.van-icon {
				margin: 20px 20px 0 20px;
				display: flex;
				align-items: center;
				justify-content: center;
				width: 57px;
				height: 57px;
				background-color: #000;
				color: white;
				border-radius: 100%;
			}
		}
		// 滑动后
		.back-fixed {
			position: fixed;
			display: flex;
			align-items: center;
			justify-content: space-between;
			width: 750px;
			height: 86px;
			top: 0;

			background-color: #f5f5f5;
			.van-icon {
				margin: 0 20px 0 20px;
				display: flex;
				align-items: center;
				justify-content: center;
				width: 57px;
				height: 57px;
				background-color: #666;
				color: white;
				border-radius: 100%;
			}
			.van-ellipsis {
				display: flex;
				align-items: center;
				justify-content: center;
				font-weight: bolder;
				font-size: 30px;
			}
		}
	}
}
</style>
