<template>
	<div class="details">
		<!-- 图片 -->
		<van-image fit="cover" :src="dataList.cover" />
		<!-- 标题、副标题 -->
		<div class="header">
			<div class="header_content">
				<span class="title">{{ dataList.cpgg_title }}</span>
				<span class="sub_title">{{ dataList.sub_title }}</span>
				
			</div>
		</div>
		<!-- 容量、模式 -->
		
		<!-- 推荐 -->
		<div class="tj">
			<div class="tj_content">
				<div class="tj_title">超值加购推荐，满足加倍~</div>
				<!-- 推荐产品信息 -->
				<div class="tj_cps">
					<!--  -->
					<div class="tj_cp" v-for="(tj, index) in dataList.tjData" :key="index">
						<div class="tj_ncp">
							<div class="tj_img"><van-image fit="cover" :src="tj.img" /></div>
							<div class="tj_price">
								<span class="tj_price_title">{{ tj.title }}</span>
								<com-price class="prices" :Sprice="tj.sprice" :Oprice="tj.oprice" :isShow="false"></com-price>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- 奶爸说 -->
		<div class="nbs">
			<div class="nbs_content">
				<span class="nbs_title">{{ dataList.nbs_title }}</span>
				<div class="nbs_user">
					<div class="nbs_name">
					<van-image round :src="dataList.img" />
					</div>
					<div class="nbs_name">{{ dataList.avatar }}</div>
				</div>
				<div class="desc">{{ dataList.desc }}</div>
			</div>
		</div>
		<!-- 商品详情 -->
		<div class="spxq">
			<div class="spxq_desc">
				<div class="spxq_title">{{dataList.spxq_title}}</div>
				<div class="spxq_descs">{{dataList.spxq_descs}}</div>
			</div>
		</div>
		<!-- 价格说明 -->
		<div class="jgsm">
			<div class="jgsm_desc">
				<div class="jgsm_title">价格说明</div>
				<!-- 最多显示三行 -->
				<div class="jgsm_descs van-ellipsis">1、面价：面价为商品的标示价格</div>
				<div class="jgsm_descs van-ellipsis">2、促俏价：促俏价格为商品的促俏价格</div>
				<div class="jgsm_descs van-multi-ellipsis--l2">3、我的钱包(优惠券)：我的钱包(优惠券)可以兑换面额与面价同等的商品</div>
				<div class="jgsm_descs van-multi-ellipsis--l2">4、商品具体成交价格以订单结算页面价格为准，如有疑问，请在购买前联系客服</div>
			</div>
		</div>
		<div class="tjdd">
			<div class="tjdd_content">
				<!-- 标题、价格、 步进器-->
				<div class="tjdd_header">
					<div class="cpgg_header">
						<div class="prices">
							<com-price 
							:numb="dataList" 
							:Sprice="dataList.sprice" 
							:Oprice="dataList.oprice"> </com-price>
							<span class="cpgg_title">{{dataList.cpgg_title}}</span>
						</div>
						
					</div>
				</div>	
				<!-- 三个按钮 -->
				<div class="tjdd_button">
					<van-button v-for="(item,index) in buts" :key="index"
						 round 
						 :disabled="dataList.count > 0 || item.id == 1 ? false : true "
						 :color="dataList.count> 0 && isColor == item.id  ? '#6D86C4':''"
						
						 @click="checked(item)">
					{{item.title}}		
					</van-button>
					
				</div>
			</div>
		</div>
	</div>
</template>

<script>
// price
import ComPrice from '@/components/common/price.vue'
// 返回
import ComButton from '../common/Button.vue'
// vuex
import {mapMutations} from 'vuex'
export default {
	components: {ComPrice,ComButton},
	props: {
		buts:{type:Array}
	},
	data(){
		return{
			// 数据
			dataList:{},
			// 默认选中立加入购物车
			isColor: 3, 
			
		}
	},
	
	created() {
		this.__init();

	},
	methods: {
		...mapMutations(
			['addGoodsToCart']
		),
		// 获取首页点击的数据详情
		async __init(){
			this.dataList = this.$route.query.data;
			console.log(this.dataList)
		},
		
		// 三个按钮
		checked(item){
			if(item.id == 1 || item.id == 2){
				return  this.$router.push(item.url)
			}else{
				// 添加到购物车
				let goods = this.dataList
				goods['checked'] = false
				goods['attrs'] = this.dataList.attrs
				// 加入购物车
				this.addGoodsToCart(goods)
				// 提示
				this.$toast('商品添加成功')
				// 返回上一级
				setTimeout(() =>{
					this.$router.go(-1)
				},1000)
			}
			
		}
		// checked(item){
		// 	this.$emit('checked',item)
		// }
		
	},
}
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/details'
</style>
