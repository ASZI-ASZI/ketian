import { login, isLogin } from "@/api/goods.js";
import { setToken, setUserInfo, removeToken, removeUserInfo } from "@/utils/auth.js";
const state = {
  user: {},
  isLogin: false,
};

const getters = {
  user: (state) => state.goods,
  isLogin: (state) => state.isLogin,
};


const mutations = {
  logout(state) {
    state.isLogin = false;
    state.goods = {};
    removeToken();
    removeUserInfo();
  },

  setUser(state, goods) { //goods={id,name}    
    state.goods =goods;
  },

  setIsLogin(state, isLogin) {
    state.isLogin = isLogin;
  },
};

const actions = {
  async login(context, user) {
    let result = await login(user);
    if (result.code == 1) {
      context.commit("setUser", result.data.user);
      context.commit("setIsLogin", true);

      setToken(result.data.token); // 
      setUserInfo(result.data.user);
    }
    return result;
  },

  async islogin(context) {
    let result = await isLogin();
    if (result.code == 1) {
      context.commit("setUser", result.data.user);
      context.commit("setIsLogin", true);

      setToken(result.data.token); //
      setUserInfo(result.data.user);
    }
    return result;
  },

  logout(context) {
    context.commit("logout");
  },

};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
