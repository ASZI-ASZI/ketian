export default {
	state:{
		// cart模拟数据
		cartList:[
			
			{
				checked:false,
				id:201,
				cpgg_title:'儿童鲜牛奶',
				cover:'https://img01.yzcdn.cn/vant/apple-1.jpg',
				subhead: 'children milk',
				// 选中的商品属性
				attrs:[
					{
						id:1,
						title:'容量',
						selected:0,
						list:[
							{name:'250ml'},
							{name:'480ml'},
							{name:'500ml'}
						],
						
					},
					{
						id:2,
						title:'模式',
						selected:0,
						list:[
							{name:'免费'},
							{name:'每周'},
							{name:'每月'}
						]
					},
					
				],
				Sprice:30.8,
				Oprice:50,
				count:1,
				minnum:1,
				maxnum:30//该商品最大商品数，与库存有关
			},
			{
				checked:false,
				id:202,
				cpgg_title:'新青年鲜牛奶2',
				cover:'https://img01.yzcdn.cn/vant/apple-2.jpg',
				subhead: 'children milk',
				// 选中的商品属性
				attrs:[
					{
						id:1,
						title:'容量',
						selected:0,
						list:[
							{name:'250ml'},
							{name:'480ml'},
							{name:'500ml'}
						],
						
					},
					{
						id:2,
						title:'模式',
						selected:0,
						list:[
							{name:'免费'},
							{name:'每周'},
							{name:'每月'}
						]
					},
					
				],
				Sprice:40,
				Oprice:80,
				count:1,
				minnum:1,
				maxnum:30//该商品最大商品数，与库存有关
			},
			{
				checked:false,
				id:203,
				cpgg_title:'新青年鲜牛奶3',
				cover:'https://img01.yzcdn.cn/vant/apple-2.jpg',
				subhead: 'children milk',
				// 选中的商品属性
				attrs:[
					{
						id:1,
						title:'容量',
						selected:0,
						list:[
							{name:'250ml'},
							{name:'480ml'},
							{name:'500ml'}
						],
						
					},
					{
						id:2,
						title:'模式',
						selected:0,
						list:[
							{name:'免费'},
							{name:'每周'},
							{name:'每月'}
						]
					},
					
				],
				Sprice:40,
				Oprice:80,
				count:1,
				minnum:1,
				maxnum:30//该商品最大商品数，与库存有关
			}
			
		],
		// 选中列表存放选中的ID
		selectedList:[],
		// 编辑弹框默认关闭
		popupShow : false,
		// 编辑(商品的索引)
		popupIndex: -1,
		
	},
	getters:{
		
		// 判断是否全选
		checkedAll:(state)=>{
			return state.cartList.length === state.selectedList.length
		},
		
		// 合计价格
		totalPrice:(state)=>{
			var total = 0
			state.cartList.forEach(v=>{
				if(state.selectedList.indexOf(v.id) > -1){
					total += v.Sprice*v.count
				}
			})
			return total
		},
		// tabbar,购物车合计数量
		cartCount(state){
			var count = 0
			state.cartList.forEach(v=>{
				if(v.count >  0){
					count += v.count
				}
			})
			return count
		},
		
		// 获取当前修改商品的属性
		popupData:(state)=>{
			return state.popupIndex > -1 ? state.cartList[state.popupIndex] : {}
		}
	},
	mutations:{
		// 全选
		selectAll(state){
			state.selectedList = state.cartList.map(v=>{
				// 设置选中状态
				v.checked = true
				return v.id
			})
		},
		// 取消全选
		unSelectAll(state){
			state.cartList.forEach(v=>{
				// 设置选中状态
				v.checked = false
			})
			state.selectedList = []
		},
		// 选中或取消某一个商品
		selectItem(state,index){
			let id = state.cartList[index].id
			let i  = state.selectedList.indexOf(id)
			// 之前是选中，则取消选中
			if(i > -1){
				// 取消当前商品选中状态
				state.cartList[index].checked = false
				// 移除选中列表中的当前商品
				return state.selectedList.splice(i,1)
			}
			// 选中
			state.cartList[index].checked = true
			state.selectedList.push(id)
		},
		//单个删除
		del(state,id){
			state.cartList.splice(id,1);
		},
		// 清空
		delAll(state){
			state.cartList.forEach(v=>{
				state.cartList = []
			})
		},
		// 初始化popupIndex
		initPopupIndex(state,index){
			state.popupIndex = index
		},
		// 加入购物车
		addGoodsToCart(state,goods){
			state.cartList.unshift(goods)
		}
		
	},
	actions:{
		//操作(全选/取消全选)
		doSelectAll({commit,getters}){
			getters.checkedAll ? commit('unSelectAll') : commit('selectAll')
		},
		//单个删除
		doDel({commit},id){
			commit('del',id)
		},
		 // 清空
		doDelAll({commit}){
			commit('delAll')
		},
		// 显示
		doShow({state,commit},index){
			commit('initPopupIndex',index)
			state.popupShow = true
		},
		// 隐藏
		doHide({state,commit}){
			state.popupShow = false
			// 初始化归-1
			commit('initPopupIndex',-1)
		}
		
	}
}
