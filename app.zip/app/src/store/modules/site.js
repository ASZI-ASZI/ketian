export default{
	state:{
		// 收件地址
		list: [
			
			{
				id:1,
				name: '张三',//姓名
				tel: '13326154345',// 手机
				province:'浙江省',
				city:'杭州市',
				county:'余杭区',
				areaCode: "330110",//地区编码，通过省市区选择获取（必填）
				addressDetail:'仓溢绿苑海曙路128号',
				isDefault: false,// 是否为默认
				postalCode:'123456'// 邮编
			},
			{
				id:2,
				name: '李四',//姓名
				tel: '13326154345',// 手机
				province:'浙江省',
				city:'杭州市',
				county:'余杭区',
				areaCode: "330110",//地区编码，通过省市区选择获取（必填）
				addressDetail:'仓溢绿苑海曙路128号',
				isDefault: true,// 是否为默认
				postalCode:'123456'// 邮编
			},
			
			
		]
		
	},
	getters:{
		// 获取默认地址
		defaultAction:(state)=>{
			return state.list.filter(v => v.isDefault)
		}
	},
	mutations:{
		// 创建收货地址
		createSite(state,item){
			state.list.unshift(item)
		},
		// 删除收货地址
		delSite(state,index){
			state.list.splice(index,1)
		},
		// 修改收货地址
		editSite(state,{index,item}){
			// 获取每一个key值
			for (let key in item) {
				state.list[index][key] = item[key]
			}
		},
		// 取消默认地址
		removeDefault(state){
			state.list.forEach((v)=>{
				if(v.isDefault){
					v.isDefault = false
				}
			})
		}
		
	},
	actions:{
		// 修改地址时改变默认地址的方法
		editAction({commit},obj){
			if(obj.item.isDefault){
				// 取消默认
				commit('removeDefault')
			}
			// 修改默认地址
			commit('editSite',obj)
		},
		// 增加地址时改变默认地址的方法
		createAction({commit},item){
			if(item.isDefault){
				// 取消默认
				commit('removeDefault')
			}
			//新增修改默认地址
			commit('createSite',item)
		}
	}
}