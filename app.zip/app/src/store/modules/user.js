import { login, isLogin } from "@/api/user.js";
import { setToken, setUserInfo, removeToken, removeUserInfo } from "@/utils/auth.js";
const state = {
  user: {},
  isLogin: false,
};

const getters = {
  user: (state) => state.user,
  isLogin: (state) => state.isLogin,
};


const mutations = {
  logout(state) {
    state.isLogin = false;
    state.user = {};
    removeToken();
    removeUserInfo();
  },

  setUser(state, user) { //user={id,name}    
    state.user = user;
  },

  setIsLogin(state, isLogin) {
    state.isLogin = isLogin;
  },
};

const actions = {
  async login(context, user) {
    let result = await login(user);
    if (result.code == 1) {
      context.commit("setUser", result.data.user);
      context.commit("setIsLogin", true);

      setToken(result.data.token); // 
      setUserInfo(result.data.user);
    }
    return result;
  },

  async islogin(context) {
    let result = await isLogin();
    if (result.code == 1) {
      context.commit("setUser", result.data.user);
      context.commit("setIsLogin", true);

      setToken(result.data.token); //
      setUserInfo(result.data.user);
    }
    return result;
  },

  logout(context) {
    context.commit("logout");
  },

};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
