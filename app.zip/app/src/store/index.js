import Vue from 'vue'
import Vuex from 'vuex'
// 本地存储
import createPersistedState from "vuex-persistedstate"



//cart.js
import cart from './modules/cart.js'
// site.js
import site from './modules/site.js'

import user from "./modules/user"

Vue.use(Vuex)

export default new Vuex.Store({
	modules: {
		cart,site ,user
	},
	// 本地存储
	plugins: [
		createPersistedState({
			storage: window.sessionStorage,
			paths: ["cart"]
		})
	],

})