<template>
	<div class="goods">
    <van-search v-model="value" shape="round" background="pink" placeholder="请输入搜索关键词" />
	</div>
	
</template>

<script>
export default {
	
}
</script>

<style scoped>

</style>