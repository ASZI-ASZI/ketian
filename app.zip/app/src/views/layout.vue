<template>
  <div>
	  <!-- <van-search
  v-model="value"
  shape="round"
  background="#4fc08d"
  placeholder="请输入搜索关键词"
/> -->
	<tab-bar :tabBar="tabBar"></tab-bar>
	<router-view  />
  </div>
</template>

<script>
  import TabBar from '@/components/common/TabBar.vue'
  
  export default{
    components: {TabBar},
    data(){
      return {
        tabBar:[
          {id:1,title:'首页',icon:'wap-home',path:'/'},
          {id:2,title:'商品',icon:'gift',path:'/shops'},
          {id:3,title:'购物袋',icon:'shopping-cart',path:'/cart'},
          {id:4,title:'我的',icon:'manager',path:'/user'}
        ]
      }
    },
	
	
	

  }
</script>

<style lang="scss" scoped>
	
</style>
