<template>
	<div class="cart">
		<!-- 加载效果 -->
		<loading-plus v-if="beforeReady"></loading-plus>
		<!-- 蓝色背景 -->
		<div class="cart_blue"></div>
		<!-- 不为空 -->
		<cart-onempty v-if="this.cartList.length > 0" :resData="cartList" @delAll="doDelAll" @selectItem="selectItem" @del="doDel" @edit="doShow">
			<!-- 合计 -->
			<template slot="checked">
				<div class="total">
					<!-- 全选 -->
					<van-checkbox checked-color="#6d86c4" icon-size="24" :value="checkedAll" @click="doSelectAll">全选</van-checkbox>
					<div class="hjs">
						<div class="hj">
							<span>合计:</span>
							<span class="Sprice">{{ totalPrice }}</span>
						</div>
					</div>

					<van-button round type="warning" size="small" :disabled="totalPrice > 0 ? false : true" @click="onSubmint">提交订单</van-button>
				</div>
			</template>
		</cart-onempty>

		<!-- 空状态 -->
		<van-empty v-else :image="url" :description="desc"><van-button round type="info" class="bottom-button" to="shops">去逛一逛吧</van-button></van-empty>

		<!-- 猜你喜欢 -->
		<div class="cps">
			<!-- header -->
			<index-head title="猜你喜欢" nIcon="replay" color="#6d86c4" value="来一啵"
			 @change="change"/>
				
			
			<!-- <com-header color="#414697" :title="`猜你喜欢`" isShow :name="`replay`" 
			:desc="`来一啵`" @change="change"></com-header> -->
			<!-- cnxh -->
			<cart-cnxh :cnxhList="datacontent" @details="onClickCart"></cart-cnxh>
		</div>

		<!-- 编辑弹框 -->
		<div class="popup">
			<van-popup :value="popupShow" round @click-overlay="doHide" position="right">
				<div class="popup_content">
					<!-- 产品图片 -->
					<van-image fit="cover" :src="popupData.cover" />
					<!-- <van-image fit="cover" :src="dataList.cover" /> -->
					<!-- 标题、价格 -->
					<div class="cpgg_title">
						<span>{{ popupData.cpgg_title }}</span>
						<div class="view-text">
							<small v-for="(item, index) in popupData.attrs" :key="index">{{ item.list[item.selected].name + '/' }}</small>
						</div>
						<com-price :Sprice="popupData.Sprice" :Oprice="popupData.Oprice" :isShow="false" />
					</div>
					<!-- 进步器 -->
					<div class="buttons"><van-stepper v-model="popupData.count" theme="round" button-size="22" disable-input /></div>
				</div>
				<!-- 容量、模式 -->
				<div class="rlms">
					<div class="rlms_content">
						<div class="rl" v-for="(item, index) in popupData.attrs" :key="index">
							{{ item.title }}
							<!-- // 容量,模式 -->
							<com-button :label="item" :selected.sync="item.selected" />
						</div>
					</div>
				</div>
				<!-- 提交 -->
				<div class="tj"><van-button round color="#f05821" @click="doHide">提交</van-button></div>
			</van-popup>
		</div>
	</div>
</template>

<script>
// 引入IndexHead组件
import IndexHead from '@/components/common/IndexHead.vue';
// 猜你喜欢
import CartCnxh from '@/components/cart/cnxh.vue';
// 不为空
import CartOnempty from '@/components/cart/onEmpty.vue';
// 价格
import ComPrice from '@/components/common/price.vue';
// 容量、模式
import ComButton from '@/components/common/Button.vue';
// vuex
import { mapState, mapGetters, mapActions, mapMutations } from 'vuex';

// 引入mixin
import loading from '@/components/mixin/loadin.js'

import {getCnxhList} from "@/api/goods.js"  //
export default {
	mixins:[loading],
	components: { IndexHead, CartCnxh, CartOnempty, ComPrice, ComButton },
	data() {
		return {
			// 图片
			url: require('../../assets/1.png'),
			// 
			cnxhList:[],
			// 描述
			desc: '客官，您的购物车空空如也！',
			datacontent: [], // 用来存放每次点击换一批出来的三个对象
			num2: '', // 用来放三个随机数
			arr: [] // 用来放三个随机数的数组，用来循环
		};
	},
	// 计算属性
	computed: {
		// totalPrice() {
		// 	return this.cartList.reduce((pre,v)=>{
		// 	  return pre + (v.checked ? v.Sprice*v.count : 0)
		// 	},0)
		// },
		// 获取vuex数据
		...mapState({
			cartList: state => state.cart.cartList,
			// 弹框显示
			popupShow: state => state.cart.popupShow
		}),
		// 是否选中全选
		...mapGetters(['checkedAll', 'totalPrice', 'popupData'])
	},

	created() {
		this.__init();
	},
	methods: {
		// 调用全选的方法
		...mapActions(['doSelectAll', 'doDel', 'doDelAll', 'doShow', 'doHide']),
		...mapMutations(['selectItem']),
		// 猜你喜欢全部数据
		async __init() {
			// this.axios.get('/home/index').then(res => {
			// 	let rul = res.data.data.cnxhList;
			// 	this.cnxhList = rul;
			// 	for (var i = 0; i < 3; i++) {
			// 		this.datacontent.push(this.cnxhList[i])
			// 	}
			// });

			let result = await getCnxhList();
			if(result.code ==1){
				this.cnxhList = result.data;
				for (var i = 0; i < 3; i++) {
					this.datacontent.push(this.cnxhList[i]);
				}
			}
		},
		// 来一啵
		change() {
			//每次点击换一批触发这个方法
			this.num2 =''
			this.arr = []
			this.datacontent = [] // 每次点击换一批就让之前的数据全清空
			// 用while来判断是否循环三次
			while(this.arr.length < 3){
				// 随机出三个0-9之间的随机数
				let num = parseInt(Math.random() * 5) 
				if (this.arr.indexOf(num) == -1) { // 获得不重复的三个数
					this.arr.push(num)
					this.num2 = num
					// 将随机数当作下标来便利data里的内容
					this.datacontent.push(this.cnxhList[this.num2]) 
				}
			}
		},
		
		// 跳转到详情
		onClickCart(item) {
			this.$router.push({path:'goods_details',query:{data:item}});
		},
		// 提交订单
		onSubmint() {
			
			this.$router.push({path:'/affirm'})
		}
	}
};
</script>

<style lang="scss" scoped>
// 全选
.van-checkbox {
	font-size: 30px;
}
// 去逛一逛吧
.van-button {
	background-color: #6d86c4;
	border: #6d86c4;
}

@import '~@/assets/scss/cartIndex';
</style>
