<template>
  <!-- 猜你喜欢 -->
  <div class="cnxh">
    <div class="cnxh_1" v-for="(item, index) in cnxhList" :key="index"
    
     @click="details(item)">
      <!-- 产品图片 -->
      <van-image fit="cover" :src="item.cover"></van-image>
      <!-- 标题、副标题 -->
      <div class="titles">
        <span class="title">{{ item.cpgg_title }}</span>
        <!-- <small class="subhead">{{ item.sub_title }}</small> -->
      </div>
      <!-- price -->
      <com-price :numb="item" :Sprice="item.sprice" :Oprice="item.oprice"> </com-price>
    </div>
  </div>
</template>

<script>
// price
import ComPrice from '@/components/common/price.vue'
export default {
  components: {ComPrice},
  
  props: {
    cnxhList:Array
  },
  created(){
    console.log(this.cnxhList)
  },
  methods: {
    // 跳转详情
    details(item) {
      this.$emit('details',item)
    }
  },
};
</script>

<style lang="scss" scoped>
.cnxh {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  width: 710px;
  height: 365px;
  border-radius: 10px;

  .cnxh_1 {
    width: 225px;
    height: 365px;
    background-color: white;
    border-radius: 10px;
    // border: 1px solid red;
    // 图片
    ::v-deep .van-image__img {
      width: 225px;
      height: 229px;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
    }
    // 标题、副标题
    .titles {
      display: flex;
      flex-direction: column;
      width: 225px;
      font-size: 20px;
      margin: 0 12px 0 12px;
      .title {
        font-weight: bold;
        color: #383838;
        margin-bottom: 5px;
      }
      .subhead {
        font-size: 18px;
        color: #aeaeae;
      }
    }
    
  }
}
</style>