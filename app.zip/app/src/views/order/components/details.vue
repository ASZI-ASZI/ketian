<template>
	<div>
		<transition name="van-fade">
			<div v-if="isShow" class="details">
				<van-nav-bar title="订单详情" @click-right="back">
					<template #right>
						<van-icon name="clear" color="#000" size="20" />
					</template>
				</van-nav-bar>
			
				<!-- Steps 步骤条 -->
				<div class="steps">
					<!-- 准备、配送中 -->
					<template v-if="orderIndex.value == 0 || orderIndex.value == 1">
						<div class="steps_title">
							<van-button round :color="orderIndex.value == index ? '#6d86c4' : ''" v-for="(item, index) in orderCheck" :key="index">{{ item.name }}</van-button>
						</div>
						<div class="icon">
							<div v-for="(items, indexs) in orderCheck" :key="indexs">
								<van-icon :name="orderIndex.value == indexs ? 'shop-collect' : 'shop-collect'" :color="orderIndex.value == indexs ? '#6d86c4' : '#aeaeae'" size="28" />
							</div>
						</div>
						<!-- 划线 -->
						<div class="lineActive"></div>
						<!-- 名称与目的地 -->
						<div class="n_d">
							<van-button round>可甜</van-button>
							<van-button round>目的地</van-button>
						</div>
						<!-- 到达时间 -->
						<div class="ddtime">
							预计
							<span class="time">19:50</span>
							送达
						</div>
					</template>
					<!-- 已完成 -->
					<template v-if="orderIndex.value == 2">
						<div class="wc">
							<div class="a">已完成</div>
							<div class="b">感谢您光临可甜!</div>
							<div class="c"><van-button round color="#6d86c4">再来一单</van-button></div>
						</div>
					</template>
				</div>
				<!-- 详情列表 -->
				<div class="xqlist">
					<!-- 地址 -->
					<div class="addres">
						<span>梦想小镇店(NO.0998)</span>
						<span class="info">浙江省杭州市余杭区仓前街道209号</span>
						<van-divider dashed :style="{ color: '#aeaeae', background: '#aeaeae' }"></van-divider>
						<!-- 配送详单 -->
						<div class="ps_xq">
							<!-- 配送与时间 -->
							<div class="dd">
								<span>配送订单:33678998726301</span>
								<span>2020-08-30 20:00</span>
							</div>
							<!-- 产品 -->
							<div class="cplist">
								<div class="cp">
									<div class="name">
										<span>新青年牛奶</span>
										<span class="sku">三天/120ml</span>
									</div>
									<span>X1</span>
									<span>￥20</span>
								</div>
								<div class="cp">
									<div class="name">
										<span>新青年牛奶</span>
										<span class="sku">三天/120ml</span>
									</div>
									<span>X1</span>
									<span>￥20</span>
								</div>
							</div>
							<van-divider dashed :style="{ color: '#aeaeae', background: '#aeaeae' }"></van-divider>
							<!-- 合计 -->
							<div class="hj">
								<span>共计2件商品</span>
								<span>实付￥40</span>
							</div>
						</div>
					</div>
				</div>
				<!-- 取奶时间 -->
				<template v-if="orderIndex.value == 2">
					<van-cell title="取奶时间" value="2020-08-10 19:50" />
				</template>
			</div>
		</transition>
		
	</div>
</template>

<script>
//headNavBar
export default {
	props: {
		orderCheck: Array,
		orderIndex: Object,
		isShow: Boolean
	},
	methods: {
		back() {
			this.$emit('back');
		}
	}
};
</script>

<style lang="scss" scoped>
// 订单详情
@import '~@/assets/scss/orderDetils';
</style>
