<template>
	<div>
		<!-- headnavbar -->
		<head-nav-bar :title="`订单列表`"   />
		<van-tabs v-model="active" swipeable sticky animated>
			<!-- tabBar -->
			<van-tab v-for="(item, index) in tabBar" :key="index" :title="item.type">
				<!-- 内容 -->
				<template v-if="item.listData.length > 0">
					<order-list :resData="item.listData" @show="show" />
				</template>
				<!-- 通用空 -->
				<template v-else>
					<order-empty />
				</template>
			</van-tab>
		</van-tabs>
		<!-- 订单详情 -->
		<order-details :isShow="isShow" @back="show" :orderCheck="orderCheck"
		:orderIndex="orderIndex" />
	</div>
</template>

<script>
//headNavBar
import HeadNavBar from '@/components/common/HeadNavBar.vue';
//列表数据
import orderList from '@/components/order/list.vue';
// 空
import orderEmpty from '@/components/order/empty.vue';
// 订单详情
import orderDetails from '@/components/order/details.vue';

import { getOrderList } from "@/api/order.js";

export default {
	components: {
		HeadNavBar,
		orderList,
		orderEmpty,
		orderDetails
	},
	data() {
		return {			
			// 默认
			active: 0,
			// head列表数据
			tabBar: [],
			// 	{
			// 		id: 1,
			// 		title: '全部',
			// 		listData: [
			// 			{
			// 				title: '1', //1：配送，2：自取
			// 				order_number: '33678998726301',
			// 				value: '0', //0:准备中 1：配送中 2：完成
			// 				site: '仓溢绿苑海曙路128号',
			// 				location: '梦想小镇店',
			// 				no: '0998',
			// 				time: '2020-08-30 20:00',
			// 				oreder_item: [
			// 					{
			// 						id: '1',
			// 						name: '新青年牛奶1',
			// 						nubmer: '1',
			// 						price: '20'
			// 					},
			// 					{
			// 						id: '2',
			// 						name: '新青年牛奶2',
			// 						nubmer: '1',
			// 						price: '20'
			// 					}
			// 				]
			// 			},
			// 			{
			// 				title: '2', 
			// 				order_number: '33678998726201',
			// 				value: '1', 
			// 				site: '仓溢绿苑海曙路128号',
			// 				location: '梦想小镇店',
			// 				no: '0998',
			// 				time: '2020-08-30 20:00',
			// 				oreder_item: [
			// 					{
			// 						id: '1',
			// 						name: '儿童早鲜奶',
			// 						nubmer: '1',
			// 						price: '20'
			// 					}
			// 				]
			// 			},
			// 			{
			// 				title: '2', 
			// 				order_number: '33678998726201',
			// 				value: '2', 
			// 				site: '仓溢绿苑海曙路128号',
			// 				location: '梦想小镇店',
			// 				no: '0998',
			// 				time: '2020-08-30 20:00',
			// 				oreder_item: [
			// 					{
			// 						id: '1',
			// 						name: '儿童早鲜奶',
			// 						nubmer: '1',
			// 						price: '20'
			// 					}
			// 				]
			// 			}
			// 		]
			// 	},
			// 	{
			// 		id: 2,
			// 		title: '立等可取',
			// 		listData: [
			// 			{
			// 				title: '1', //1：配送，2：自取
			// 				order_number: '33678998726301',
			// 				value: '2', //1：完成，2：进行中
			// 				site: '测试地址',
			// 				location: '梦想小镇店',
			// 				no: '0998',
			// 				time: '2020-08-30 20:00',
			// 				oreder_item: [
			// 					{
			// 						id: '1',
			// 						name: '老年牛奶',
			// 						nubmer: '1',
			// 						price: '20'
			// 					}
			// 				]
			// 			}
			// 		]
			// 	},
			// 	{
			// 		id: 3,
			// 		title: '预约订单',
			// 		listData: []
			// 	}
			// ],
			//订单详情默认不显示
			isShow: false,
			orderIndex:{},
			// 详情状态
			orderCheck:[
				{id:'1',name:'准备中'},
				{id:'2',name:'配送中'},
				{id:'3',name:'完成'}
			]
			
		};
	},
	async created(){
		this.getOrderDetils();
		
		try{
        let result = await getOrderList();

        console.log(result);

        if (result.code == 1) {
          this.tabBar = result.data;
        }
      	} catch (error) {
        	console.log(error);
      	}	
	
	},
	
	methods: {
		// 显示订单详情
		show(item) {
			this.isShow = !this.isShow
			this.$root.bus.$emit('showAction',item)
		},
		// 获取详情
		getOrderDetils(){
			this.$root.bus.$on('showAction',v => {
				this.orderIndex = v
			})
		}
	},
	// 移除
	beforeDestroy(){
		this.$root.bus.$off('showAction',this.getOrderDetils())
	},
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/orderIndex';
</style>
