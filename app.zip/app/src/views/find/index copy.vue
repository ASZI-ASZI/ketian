<template>
	<div>
		<van-button type="primary" @click="show = true">SKU</van-button>
		<van-sku v-model="show" :sku="sku" :goods="goods" 
		 />
	</div>
</template>

<script>
export default {
	data() {
		return {
			show: false,
			goods: {
				// 默认商品 sku 缩略图
				picture: require('@/assets/img/nn1.png')
			},
			sku: {
				tree: [
					{
						k_id: 123, // 属性id
						k: '容量', // 属性名
						k_s: 's1',
						v: [{ id: 1, name: '250ml' }, { id: 2, name: '480ml' }, { id: 3, name: '500ml' }]
					},
					{
						k_id: 2, // 属性id
						k: '规格',
						k_s: 's2',
						v: [
							{
								id: 1, // 属性值id
								name: '三天',
								numb: 3
							},
							{
								id: 2,
								name: '每周',
								numb: 7
							},
							{
								id: 3,
								name: '每月',
								numb: 30
							}
						]
					}
				],
				// 所有 sku 的组合列表
				list: [
					// 1
					{
						id: 2259,
						s1: '1',
						s2: '1',
						price: '180',
						stock_num: 110,
						
					},
					{
						id: 2260,
						s1: '2',
						s2: '1',
						price: '200',
						stock_num: 200
					},
					{
						id: 2261,
						s1: '3',
						s2: '1',
						price: '300',
						stock_num: 300
					},
					//2
					{
						id: 2262,
						s1: '1',
						s2: '2',
						price: '480',
						stock_num: 110
					},
					{
						id: 2263,
						s1: '2',
						s2: '2',
						price: '200',
						stock_num: 200
					},
					{
						id: 2264,
						s1: '3',
						s2: '2',
						price: '300',
						stock_num: 300
					},
					// 3
					{
						id: 2265,
						s1: '1',
						s2: '3',
						price: '180',
						stock_num: 110
					},
					{
						id: 2266,
						s1: '2',
						s2: '3',
						price: '200',
						stock_num: 200
					},
					{
						id: 2267,
						s1: '3',
						s2: '3',
						price: '300',
						stock_num: 300
					}
				],
				price: '6', // 默认价格（单位元）
				stock_num: 227 // 商品总库存
			},
			
		};
	}
};
</script>

<style scoped></style>
