<template>
	<div>
		<!-- head -->
		<head-nav-bar :title="`门店详情`" />
		<!-- 轮播图 -->
		<van-swipe class="my-swipe" :autoplay="3000"
		:show-indicators="false"
		@change="onChange">
			<van-swipe-item v-for="(image, index) in images" :key="index">
				<img v-lazy="image" />
			</van-swipe-item>
			
			<!-- 自定义指示器 -->
			<template #indicator>
				<div class="custom-indicator">
				  {{ current + 1 }}/4
				</div>
			</template>
		</van-swipe>
		<!-- 详细地址及营业时间 -->
		<div class="xxdz">
			<div class="xxdz_content">
				<span class="title">利尔达科技园店（No.0248）</span>
				<div class="yysj">
					<span class="subtitle">营业时间:</span>
					<div class="time">
						<span>周一至周五 07:30-20:30</span>
						<span>周六 08:00-20:30</span>
						<span>周末 全天不营业</span>
					</div>
				</div>
				<div class="mddz">
					<span class="subtitle">门店地址:</span>
					<div class="time">
						<span>余杭区仓前街道文一西路1328号利尔达科技园1号楼一层</span>
					</div>
				</div>
			</div>
		</div>
		<!-- 地图 -->
		<div class="dt">
			<div class="dt_content">
				<span>门店地图</span>
				<span class="dtwz">地图</span>
				<img class="dttp"  src="@/assets/img/nn1.png" alt="" >
			</div>
		</div>
		<!-- 去逛一逛 -->
		<div class="gyg">
			<van-button block round color="#6d86c4" @click="goToShops">去逛一逛</van-button>
		</div>
	</div>
</template>

<script>
// header
import HeadNavBar from '@/components/common/HeadNavBar.vue';
export default {
	components: { HeadNavBar },
	data() {
		return {
			images: [
				'https://tse3-mm.cn.bing.net/th/id/OIP-C.QH1JChykWbl5-7MlfXxC_AHaEo?w=265&h=180&c=7&r=0&o=5&dpr=1.25&pid=1.7',
				'https://tse1-mm.cn.bing.net/th/id/OIP-C.Mk_WEPDvFcvlgmo9nJYvgQHaE7?w=247&h=180&c=7&r=0&o=5&dpr=1.25&pid=1.7',
				'https://tse2-mm.cn.bing.net/th/id/OIP-C.0XbY_ZzhaoO0ypsRlJ_QNwHaE7?w=297&h=197&c=7&r=0&o=5&dpr=1.25&pid=1.7',
				'https://tse4-mm.cn.bing.net/th/id/OIP-C.ZyQDNAn8fCwJt20Mk6Cz-AHaE7?w=296&h=197&c=7&r=0&o=5&dpr=1.25&pid=1.7',
			],
			current:0
		};
	},
	methods:{
		//轮播图 
		onChange(index) {
		    this.current = index;
		},
		// goToShops
		goToShops(){
			this.$router.push({
				path:'/shops'
			})
		}
	}
};
</script>

<style lang="scss" scoped>
// 轮播图
.my-swipe {
	margin: 0 20px;
	width: 710px;
	height: 372px;
	// background-color: red;
	border-radius: 10px;
	.van-swipe {
		height: 372px;
		width: 710px;
		border-radius: 10px;
		margin-top: 64px;
	}
	.van-swipe-item {
		width: 710px;
		border-radius: 10px;
		color: #fff;
		font-size: 15px;
		text-align: center;
		& > img {
			width: 710px;
			height: 372px;
		}
	
	}
	// 自定义指示器
	 .custom-indicator {
	    position: absolute;
	    right: 17px;
	    bottom: 17px;
	    padding: 2px 5px;
	    font-size: 12px;
	    background-color: #000;
		color: white;
		border-radius: 50px;
		width: 88px;
		height: 46px;
		display: flex;
		align-items: center;
		justify-content: center;
	}
}
// 详细地址及营业时间
.xxdz{
	margin: 20px 20px;
	width: 710px;
	// height: 292px;
	height: 100%;
	background-color: white;
	border-radius: 10px;
	display: flex;
	// border: 1px solid black;
	font-size: 30px;
	.xxdz_content{
		margin: 30px 18px ;
		// background-color: red;
		height: 222px;
		width: 674px;
		// 营业时间
		.yysj{
			display: flex;
			font-size: 20px;
			margin-top: 10px;
			margin-bottom: 10px;
			.subtitle{
				width: 120px;
				color: #838383;
			}
			.time{
				display: flex;
				flex-direction: column;
			}
		}
		// 门店地址
		.mddz{
			// @extend .yysj;
			display: flex;
			font-size: 20px;
			.subtitle{
				width: 120px;
				color: #838383;
			}
		}
	}
}
// 地图
.dt{
	margin: 20px 20px;
	width: 710px;
	height: 440px;
	border-radius: 10px;
	font-size: 30px;
	background-color: white;
	display: flex;
	.dt_content{
		display: flex;
		flex-direction: column;
		margin: 10px 10px;
		// background-color: mistyrose;
		width: 690px;
		height: 380px;
		.dtwz{
			margin-top: 10px;
		}
		.dttp{
			height:410px;
			 width:500px;
			 margin: auto;
			 border-end-start-radius: 30%;
			 border-start-end-radius: 30%;
			 border-start-start-radius: 5%;
			 border-end-end-radius: 5%;
		}
	}
}
// 逛一逛
.gyg{
	position: fixed;
	bottom: 0;
	left: 20px;
	right: 20px;
	width: 710px;
	height: 123px;
	// background-color: red;
	z-index: 9999;
	display: flex;
	align-items: center;
}
</style>
