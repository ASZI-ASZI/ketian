<template>
	<div>
		<!-- 标题导航 -->
		<div class="navBar">
			<div class="icon">
				<van-icon name="arrow-left" size="25" @click="back" />
			</div>
			<!-- 三项选择 -->
			<div class="sx">
				<van-button round 
				:color="sxIndex == index ? 'white':''"
				v-for="(item,index) in sxList" :key="index"
				@click="check(index)"
				>{{item.name}}</van-button>
			</div>
			<div class="icon">
				<van-icon name="location-o" size="25"></van-icon>
			</div>
		</div>
		<!-- 当前定位 -->
		<div class="dqdw" @click="location">
			<div class="dqdw_c" >
				<div class="dz" >杭州</div>
				<van-icon color="#aeaeae" name="arrow-down" size="small"></van-icon>
				<van-search v-model="value" placeholder="输入地址寻找周边可甜门店" />
			</div>
		</div>
		<!-- 对应标题导航的内容 -->
		<div v-if="sxIndex == index"
			v-for="(item,index) in sxList" :key="index">
			<div class="content" v-for="(items,indexs) in item.sxData">
				<!-- 详情 -->
				<div class="xq" >
					<!-- 标签、名称、距离 -->
					<div class="xq_info">
						<div class="name">
							<van-tag color="#6d86c4">{{items.title}}</van-tag>
							<span class="span">{{items.site}}（No.{{items.num}}）</span>
						</div>
						<span>{{items.distance}}m</span>
					</div>
					<!-- 营业时间 -->
					<div class="time">
						<van-icon name="clock-o"></van-icon>
						<span class="times">{{items.business_hours}}</span>
						<van-tag round color="#e5e5e5">打烊</van-tag>
					</div>
					<!-- 详情地址 -->
					<div class="address">
						<div class="wz">
							<van-icon name="location-o" />
							<!-- 最多显示两行 -->
							<span>
								{{items.detailed_address}}
							</span>
						</div>
						<div class="ckxq" @click="ckxq">查看详情</div>
					</div>
				
				</div>
			</div>
		</div>
		
	</div>
</template>

<script>
	export default {
		data() {
			return {
				value:'',
				sxIndex:0,
				sxList:[
					{
						id:'1',
						name:'门店自提',
						sxData:[
							{
								title:'可甜',
								site:'利尔达科技园店',
								num:'0248',
								distance:'664',//距离
								business_hours:'07:30-20:00',//营业时间
								detailed_address:'余杭区仓前街道文一西路1328号利尔达科技园1号楼'
							},
							{
								title:'可甜1',
								site:'利尔达科技园店1',
								num:'0248',
								distance:'660',//距离
								business_hours:'07:30-20:00',//营业时间
								detailed_address:'余杭区仓前街道文一西路1328号利尔达科技园1号楼'
							}
						]
						
					},
					{
						id:'2',
						name:'送货上门',
						sxData:[
							{
								title:'可甜1',
								site:'梦想小镇店',
								num:'0248',
								distance:'665',//距离
								business_hours:'07:30-20:00',//营业时间
								detailed_address:'余杭区仓前街道文一西路1328号利尔达科技园1号楼'
							}
							
						]
						
					},
					{
						id:'3',
						name:'奶即购',
						sxData:[]
					}
				]
			}
		},
		
		methods: {
			// 
			check(index){
				this.sxIndex = index
			},
			// back
			back(){
				this.$router.go(-1)
			},
			// 定位
			location(){
				this.$router.push({path:'/location'})
			},
			// 查看详情(门店详情)
			ckxq(){
				this.$router.push({path:'/outlet'})
			}
			
		},
	}
</script>

<style lang="scss" scoped>
.navBar {
    height: 60px;
	width: 710px;
	margin: 10px 20px;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 40px;
	background-color: #f5f5f5;
	
	// 三项选择
	.sx{
		height: 100%;
		width: 540px;
		border-radius: 50px;
		background-color: #6d86c4;
		
		display: flex;
		justify-content: space-between;
		::v-deep .van-button__text{
			color: black;
			font-size: 20px;
		}
		
		// 按钮样式
		::v-deep .van-button{
			margin-top: 5px;
			margin-bottom: 5px;
			margin-left: 5px;
			margin-right: 5px;
			width: 180px;
			height: 50px;
			background-color: #6d86c4;
			border: none;
		}
		
	}
	.icon{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
}
// 当前定位
.dqdw{
	margin: 20px 20px;
	height: 57px;
	width: 710px;
	background-color: white;
	border-radius: 10px;
	font-size: 20px;
	
	.dqdw_c{
		margin: 0 20px;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 57px;
		.van-icon{margin-left: 20px;}
		::v-deep .van-search{
			width: 520px;
			margin-left: 50px;
			padding: 0;
			.van-search__content{
				background-color: white;
				border: none;
				height: auto;
				height: 57px;
				
			}
		}
		
	}
	
}
//对应标题导航的内容
.content{
	margin: 17px 20px;
	width: 710px;
	height: 186px;
	border-radius: 10px;
	background-color: white;
	display: flex;
	// border: 1px solid black;
	// 详情
	.xq{
		margin: 10px 20px;
		height: 166px;
		width: 670px;
		// background-color: green;
		font-size: 30px;
		.xq_info{
			display: flex;
			justify-items: center;
			justify-content: space-between;
			.name{
				.span{margin-left: 20px;}
			}
		}
		// 营业时间
		.time{
			margin-top: 17px;
			margin-bottom: 17px;
			// background-color: red;
			color: #b3b3b3;
			width: 690px;
			height: 30px;
			display: flex;
			align-items: center;
			.times{
				margin-left: 10px;
			}
			.van-tag{
				margin-left: 10px;
			}
		}
		// 详情地址
		.address{
			display: flex;
			align-items: center;
			justify-content: space-between;
			color: #b3b3b3;
			height: 40px;
			.ckxq{color: #6d86c4;}
			.wz{
				width: 500px;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
			}
		}
		
	}
	
}
</style> 