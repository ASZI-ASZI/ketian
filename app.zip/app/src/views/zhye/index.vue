<template>
  <div class="bg">
    <van-nav-bar title="账户余额" left-text="返回" left-arrow @click-left="onClickLeft" />
      <div class="dk">
        <div class="xz">当前余额（元）</div>
        
      </div>
      <div class="dz">¥666,666</div>
      <div class="an">
      <van-button color="linear-gradient(to right, #ff6034, #ee0a24)" round type="info">现在付款</van-button>
      <van-button color="linear-gradient(to right, #7232dd, #4B0082)" round type="info">现在提现</van-button>
      </div>
  </div>
</template>

<script>
export default {
  methods: {
    onClickLeft() {
      this.$router.push("user");
    }
  }
};

import Vue from "vue";
import { NoticeBar } from "vant";
import { Empty } from "vant";

Vue.use(Empty);
Vue.use(NoticeBar);
</script>

<style scoped>
.bg{
  display:grid;
  width: 100%;
  height: 800px;
}
.dk{
     display: flex;
     width: 80%;
     height: 300px;
     background-color: burlywood;
     border-radius: 25px;
     margin: 5% 10% 10% 10%;
   }
.xz{
  margin-top: 60px;
  width: 600px;
  color: rgb(255, 255, 255);
  text-align: center;
  font-size: 30px;
  
}
.dz{
  margin-top: -250px;
  width: 78%;
  color: white;
  text-align: center;
  font-size: 60px;
  margin-left: 10%;
}
.an{
    display: flex;
    align-items: center;
    justify-content: space-between; 
     width: 60%;
     height: 300px;
     border-radius: 25px;
     margin: -25% 10% 10% 20%;
     
   }
   
</style>
