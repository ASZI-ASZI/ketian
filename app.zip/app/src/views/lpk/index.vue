<template>
	<div>
		<!-- HeadNavBar -->
		<head-nav-bar />
		<!-- 优惠券 -->
		<van-list
		v-model="loading" 
		:finished="finished" 
		finished-text="已经全部加载完成" @load="onLoad">
			<coupon-index :resData="couponData" @ljss="ljss"> </coupon-index>
		</van-list>
	</div>
</template>


<script>

//HeadNavBar
import HeadNavBar from '@/components/common/HeadNavBar2.vue'
//coupon
import CouponIndex from "./components/lpkindex.vue";

import {getlpkList}  from "@/api/lpk.js"

export default {
	components: { HeadNavBar, CouponIndex },
	data() {
		return {
			// 承载数据
			couponData: [],
			//加载状态
			loading: false,
			// 控制加载状态
			finished: false
		};
	},
	async created(){
		let result  = await getlpkList();
		if(result.code ==1 ){
			this.couponData = result.data;
		}
	},
	methods: {
		// 数据加载
		onLoad() {
	
		},
		//使用优惠券
		ljss() {
			this.$router.push('shops');
		},
		
	}
};
</script>

<style lang="scss" scoped>
	// ::v-deep .van-nav-bar .van-icon  {
	//     color: #000;
	// }
	// ::v-deep .van-nav-bar .van-nav-bar__text{
	// 	color: #000;
	// }
</style>
