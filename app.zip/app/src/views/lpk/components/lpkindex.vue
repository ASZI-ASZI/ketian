<template>
	<div>
		<div class="yhj" v-for="(item, index) in resData" :key="index">
			
			<div class="coupon">
				<div class="content">
					<span class="title">{{ item.title }}</span>
					<span class="time">{{ item.time }}</span>
				</div>
				<div class="zk">
					{{ item.zk }}
					<small>张</small>
				</div>
			</div>
			
			<div class="sygz">
			</div>
		</div>
	</div>
</template>

<script>
export default {
	props: {
		resData: Array,
		isShow: {
			type: Boolean,
			default: true
		}
	},
	data() {
		return {
			
			ssgz: []
		};
	},
	methods: {
		
		onLoad() {
			this.$emit('onLoad');
		},

		
		ljss() {
			this.$emit('ljss');
		}
	}
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/couponIndex';
</style>
