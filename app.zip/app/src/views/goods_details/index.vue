<template>
	<div id="goods_details">
		<!-- 收藏、返回上一级 -->
		<goods-about id="about"
			:isSelected="isSelected" 
			:isOpacity="isOpacity" 
			@prev="prev" @collect="collect">
		</goods-about>
		<!-- 产品详情 -->
		<goods-details :buts="buts" id="details"/>
		
	</div>
</template>

<script>
	//收藏、返回上一级
	import GoodsAbout from '@/components/goods_details/about.vue'
	// 产品详情
	import GoodsDetails from '@/components/goods_details/details.vue'
	
	export default {
		components: {GoodsAbout,GoodsDetails},
		data() {
			return {
				
				// 动态style属性
				isOpacity: {opacity: 0},
				// 收藏与取消收藏
				isSelected:false,
				// 按钮
				buts:[
					{id:'1',title:'充一赠一',url:'cz'},
					{id:'2',title:'立即购买',url:'affirm'},
					{id:'3',title:'加入购物车',url:'addCart'},
				],
			}
		},
		
		// 在组件挂载完成的时添加监听事件
		mounted() {
			window.addEventListener('scroll', this.handleScroll);
		},
		methods: {
			
			//获取滚动条距离顶部的距离
			handleScroll() {
				//获取滚动条距离顶部的距离
				var top = document.documentElement.scrollTop || document.body.scrollTop;
				/* 滚动条距离顶部的距离达到400时候,opacity==1 */
				var opacity = top / 200;
				if (opacity >= 1) {
					opacity = 1;
				}
				this.isOpacity.opacity = opacity;
			},
			// 返回上一级
			prev(event) {this.$router.go(-1)},
			// 收藏、取消收藏
			collect(){
				this.isSelected = !this.isSelected 
				if(this.isSelected){
					this.$toast('收藏成功')
					
				}else{
					this.$toast('取消收藏')
				}
				
			},
			// // 按钮当前选项
			// checked(item){
			// 	if(item.id == 1 || item.id == 2){
			// 		return  this.$router.push(item.url)
			// 	}else{
			// 		// 添加到购物车
			// 		let goods = this.detail
			// 		goods['checked'] = false
			// 		goods['attrs'] = this.attrs
			// 		// 加入购物车
			// 		this.addGoodsToCart(goods)
			// 		this.$toast('加入成功')
			// 	}
				
			// }
		},
		
		// 在组件卸载时（退出页面）移除监听函数
		destroyed() {
			window.removeEventListener('scroll', this.handleScroll);
		}
		
	}
	
</script>

<style lang="scss" scoped>

</style>