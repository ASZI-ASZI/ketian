<template>
  <div>
    <!-- headnavbar -->
    <head-nav-bar :title="`登录`" />
    <!-- logo -->
    <com-logo :logo="this.logo"></com-logo>
    <!-- 登录表单 -->
    <div class>
      <div class>
        <van-cell-group :border="false">
          <!-- 请输入 -->
          <van-field v-model="loginForm.name" label="用户名：" placeholder="请输入用户名" />
          <!-- 输入密码 -->
          <van-field v-model="loginForm.pwd" type="password" label="密码：" placeholder="请输入密码"/>
        </van-cell-group>
      </div>

      <!-- 确定按钮 -->
      <div class="button">
        <van-button color="linear-gradient(to right, pink, pink)" round block type="info" @click="onClickLogin">登录</van-button>
      </div>

      <div class="xx"><van-button type="primary" round url="http://localhost:8080/#/register" size="large" color="linear-gradient(to right, pink, pink)">新用户注册</van-button></div>
    </div>
  </div>
</template>

<script>
//headNavBar
import HeadNavBar from "@/components/common/HeadNavBar.vue";
// logo
import ComLogo from "@/components/common/logo.vue";

import Vue from "vue";
import { Toast } from "vant";
Vue.use(Toast);

export default {
  components: {
    HeadNavBar,
    ComLogo
  },
  data() {
    return {
      // logo
      logo: require("../../assets/logo.png"),
      // 登录表单
      loginForm: {
        name: "", //手机号码
        pwd: "", //验证码
        //协议
        checked: "" //是否勾选
      }
    };
  },

  methods: {
    //返回上一级
    prev() {
      this.$router.go(-1);
    },

    //登录
    async onClickLogin() {
      //console.log(e);
      let params = { name: this.loginForm.name, pwd: this.loginForm.pwd };
      console.log(params);
      let result = await this.$store.dispatch("user/login", params);
      console.log(result);
      if (result.code == 1) {
        this.$router.push({ name: "user" });
        return;
      }
      Toast("登录失败");
    }
  }
};
</script>

<style lang="scss" scoped>
// @import '~@/assets/scss/loginIndex'
</style>
