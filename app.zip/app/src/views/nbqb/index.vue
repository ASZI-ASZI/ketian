<template>
  <div>
    <!-- HeadNavBar -->
    <head-nav-bar :title="`奶爸钱包`" />
    <!-- 内容 -->
    <div class="lbt">
      <van-swipe :autoplay="3000" indicator-color="white">
        <!-- :indicator-color="`#3d44a8`" -->
        <van-swipe-item v-for="(item,index) in resData" :key="index">
          <van-image class="img" :src="item.img" />
        </van-swipe-item>
      </van-swipe>
    </div>

    <div class="content">
      <!-- 空内容 -->
	  
      <van-empty :image="url" :description="desc"></van-empty>
      <!-- 有内容 -->
    </div>
    <!-- 底部 -->
    <div class="tj">
      <div class="sub_button">
        <small>充一送一</small>
      </div>
      <div class="button">
        <van-button
          v-for="(item, index) in buts"
          :key="index"
          round
          :color="isColor == item.id ? '#6D86C4' : ''"
          @click="checked(item)"
        >{{ item.title }}</van-button>
      </div>
    </div>
  </div>
</template>

<script>
//HeadNavBar
import HeadNavBar from "@/components/common/HeadNavBar.vue";
import ComLogin from "@/components/common/login_back.vue";
export default {
  components: { HeadNavBar, ComLogin },
  data() {
    return {
      //默认选择
      tj: "3",
      // 图片
      url: require("../../assets/1.png"),
      // 描述
      desc: "客官，您的钱包空空如也！",
      // 按钮
      buts: [
        { id: "1", title: "幸运送", url: "xys" },
        { id: "2", title: "发红包", url: "vhb" },
        { id: "3", title: "充值钱包", url: "czqb" }
      ],
      // 默认选中充值钱包
      isColor: 3
    };
  },
  methods: {
    // 返回
    prev() {
      this.$router.go(-1);
    },
    // 当前选项
    checked(item) {
      this.isColor = item.id;
      this.$router.push(item.url);
    }
  }
};
</script>

<style lang="scss" scoped>
@import "~@/assets/scss/nbqb";



.lbt{
	display: flex;
	margin: -350px 20px 20px 20px ;
	height: 254px;
	border-radius: 10px;
	// background-color: #f7dfde;
	.van-swipe {
		height: 254px;
		width: 710px;
		border-radius: 10px;
		// margin-top: 64px;
	}
	.van-swipe-item {
		width: 710px;
		height: 254px;
		border-radius: 10px;
		color: #fff;
		font-size: 15px;
		text-align: center;
		& > img {
			max-height: 100%;
			max-width: 100%;
		}
	}
}

</style>

