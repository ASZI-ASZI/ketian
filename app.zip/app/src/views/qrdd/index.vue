<template>
	<div>
		<!-- HeadNavBar -->
		<head-nav-bar :title="`确认定单`"  />
		<!-- 单元格 -->
		<div class="cell">
			<!-- 充值订单列表 -->
			<van-cell-group>
				<van-cell v-for="(item, index) in cellData" :value="'￥' + item.price">
					<template #title>
						<span class="custom-title">{{ item.title }}</span>
						<span class="number">{{ 'x' + item.number }}</span>
						<!-- <van-tag type="warning" mark>{{'x'+item.number}}</van-tag> -->
					</template>
				</van-cell>
			</van-cell-group>
			<!-- 赠送的列表 -->
			<div class="zs">
				<van-cell-group><van-cell v-for="(item, index) in zsData" center :title="item.title" :value="'x' + item.number" :label="item.label" /></van-cell-group>
			</div>
			<!-- 统计 -->
			<div class="tj">
				<van-cell-group><van-cell :title="'共' + tj.number + '张'" :value="'小计' + '￥' + tj.price" /></van-cell-group>
			</div>
		</div>
		<!-- 支付方式 -->
		<com-pay :resData="actions" :pay="pay" @onSelect="onSelect" @show="show"></com-pay>
		
		<!-- 支付协议 -->
		<div class="zfxy">
			<div class="title">
				<van-checkbox v-model="checked" label-disabled checked-color="#6d86c4" icon-size="20">
					<span>我已阅读并同意</span>
					<small class="small">《支付协议》</small>
				</van-checkbox>
				<div class="van-multi-ellipsis--l4">
				 {{zfxy.desc}}
				</div>
			</div>
		</div>
		<!-- 提交 -->
		<van-submit-bar label="应付合计"  
		:price="this.price" 
		:disabled="this.checked ? false : true"
		text-align="left" button-text="去结算" @submit="onSubmit" />
	</div>
</template>

<script>
//HeadNavBar
import HeadNavBar from '@/components/common/HeadNavBar.vue'
// 支付
import ComPay from '@/components/common/pay.vue'
export default {
	components: {HeadNavBar,ComPay},
	data() {
		return {
			// 充值订单列表
			cellData: [
				{ price: '68', title: 'A1全场通用', number: '1' }, 
			    { price: '88', title: 'B1全场通用', number: '1' },
				{ price: '188', title: 'C1全场通用', number: '1' }
			],
			//赠送的列表
			zsData: [
				{ title: 'A1全场通用', number: '1', label: '赠送' },
				{ title: 'B1全场通用', number: '1', label: '赠送' },
				{ title: 'C1全场通用', number: '1', label: '赠送' }
			],
			// 统计
			tj: {
				number: '6',
				price: '344'
			},
			
			//价格统计
			price:33400,
			// 复选
			checked: true,
			//pay
			pay:{
				// radio: '3',
				isShow: false,
				icon:'alipay',
				value: 'alipay',
				title:'支付宝',
			},
			// 支付方式
			actions: [
				{ id: 1, name: '1', title: '奶爸钱包', value: 'nbqb',icon:'gold-coin',balance:'50' },
				{ id: 2, name: '2', title: '微信支付', value: 'wxpay',icon:'wechat',balance:'' },
				{ id: 3, name: '3', title: '支付宝',   value: 'alipay',icon:'alipay',balance:'' },
			],
			// 对付协议
			zfxy:{
				desc:'温馨提示：仅支持开具电子发票，订单完成后可前往发票管理中开具，根据国家税务总局2016年第53号《关于营改增试点若干管问题的公告》，向购卡，充值人开具“预付卡销售”增值税普通发票。'
			}
			
		};
	},
	methods: {
		
		//显示
		show(){this.pay.isShow = true},
		//pay
		onSelect(item){
			this.pay.radio = item.name;
			this.pay.icon = item.icon;
			this.pay.isShow = false;
			this.pay.title = item.title;
			this.pay.value = item.value;
		},
		// 结算
		onSubmit(item) {
			this.$router.push('user')
		}
	}
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/qrddIndex'
</style>
