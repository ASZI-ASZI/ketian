<template>
  <div>
    <!-- headnavbar -->
    <head-nav-bar :title="`收货地址`" />
    <!-- 收货地址列表 -->
    <address-list />
  </div>
</template>

<script>
//headNavBar
import HeadNavBar from "@/components/common/HeadNavBar.vue";
//地址列表
import AddressList from "./components/list.vue";


export default {
  components: { HeadNavBar, AddressList },
  data() {
    return {};
    
  },  
  methods: {}
};
</script>

<style lang="scss" scoped></style>
