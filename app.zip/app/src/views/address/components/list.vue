<template>
  <div>
    <!-- 收货地址列表 -->
    <van-swipe-cell v-for="(item, index) in list" :key="index">
      <van-cell :label="item.addressDetail" clickable @click="check(item)">
        <template #title>
          <span class="custom-title">{{ item.name }}</span>
          <span class="tel">{{ item.tel }}</span>
          <van-tag mark :type="item.isDefault ? 'warning':''">{{ item.isDefault ? '默认' : '' }}</van-tag>
        </template>
        <template #right-icon>
          <van-radio checked-color="#6d86c4" v-model="radios" :name="item.id" />
        </template>
      </van-cell>
      <template #right>
        <div class="right">
          <van-button @click="del(index)" square color="#f05821" text="删除" />
          <van-button @click="edit(index)" square color="#6d86c4" text="编辑" />
        </div>
      </template>
    </van-swipe-cell>
    <!-- 新增 按钮-->
    <div class="buttons">
      <van-button round block color="#6d86c4" @click="onAdd">新增</van-button>
    </div>
    <!-- 编辑、新增收货地址 -->
    <div class="address" v-if="isShwo">
      <van-address-edit
        :area-list="form.areaList"
        :address-info="addresInfo"
        show-postal
        show-set-default
        show-search-result
        :search-result="form.searchResult"
        :area-columns-placeholder="['请选择', '请选择', '请选择']"
        @save="onSave"
      />
      <div class="qx">
        <van-button color="#f05821" @click="qx">取消</van-button>
      </div>
    </div>
  </div>
</template>

<script>
// vuex
import { mapState, mapMutations, mapActions } from "vuex";
// 地区js
import areaList from "@/assets/area.js";
import { getAddressList } from "@/api/address.js";
export default {
  data() {
    return {
      list: [], //kexuandizhiliebiao
      // 选中的地址
      radios: [],
      // 判断是否从其他页面来获取收货地址
      isChoos: false,
      // 是否示编辑、新增 收货地址
      isShwo: false,
      //创建
      form: {
        areaList,
        searchResult: []
      },
      // 新增收货地址
      addresInfo: {
        id: "",
        name: "", //姓名
        tel: "", // 手机
        province: "",
        city: "",
        county: "",
        areaCode: "", //地区编码，通过省市区选择获取（必填）
        addressDetail: "",
        isDefault: false, // 是否为默认
        postalCode: "" // 邮编
      },
      // 创建或修改收货地址（默认为创建）
      isEdit: false,
      //当前修改对象的索引
      index: -1
    };
  },
  async created() {
    let result = await getAddressList();
    if (result.code == 1) {
      this.list = result.data;
	}
	
	console.log(result.data)
  
  
    // 接way.vue传过来的值
    let v = this.$route.query.type;

    if (v === "choose") {
      this.isChoos = true;
	}
  },

  methods: {
    ...mapMutations(["delSite"]),
    ...mapActions(["editAction", "createAction"]),
    // 新增
    onAdd(item) {
      this.isShwo = true;
      this.addresInfo = {};
    },
    // 删除(i为vuex传过来的索引)
    del(i) {
      this.$dialog
        .confirm({
          title: "友情提示",
          message: "确定要删除该条数据吗？"
        })
        .then(() => {
          this.delSite(i);
        });
    },
    // 修改
    edit(i) {
      this.isShwo = true;
      // 获取json格式数据
      let obj = JSON.stringify({
        index: i,
        item: this.list[i]
      });
      if (obj) {
        // 取出并赋值
        let result = JSON.parse(obj);
        this.addresInfo = result.item;
        this.index = result.index;
        this.isEdit = true;
      }
    },

    //保存
    onSave(item) {
      // 修改
      if (this.isEdit) {
        this.editAction({
          index: this.index,
          item
        });

        setTimeout(() => {
          this.isShwo = false;
        }, 100);
        return;
      }

      // 创建
      this.createAction(item);

      setTimeout(() => {
        this.isShwo = false;
      }, 100);
    },
    // 取消
    qx() {
      setTimeout(() => {
        this.isShwo = false;
      }, 100);
    },
    // 选中
    check(item) {
      if (this.isChoos) {
        this.radios = item;
        // 返回上一页
        this.$router.go(-1);
      }
    }
  },
  // 广播事件
  destroyed() {
    // 广播事件
    this.$root.bus.$emit("choosAction", this.radios);
  }
};
</script>

<style lang="scss" scoped>
.van-cell {
  position: relative;
  display: flex;
  align-items: center;
  font-size: 30px;
  box-sizing: border-box;
  width: 710px;
  height: 160px;
  overflow: hidden;
  color: #323233;
  line-height: 30px;
  background-color: white;
  border-radius: 10px;
  margin: 20px 20px;
  .tel {
    margin-left: 10px;
    color: #323233;
  }
  //tab
  .van-tag {
    margin-left: 10px;
  }
  // .van-icon-delete::before {
  // 	margin-left: 40px;
  // }
  .van-cell__label {
    margin-top: 10px;
    color: #969799;
    font-size: 12px;
    line-height: 30px;
    width: 500px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}

::v-deep .van-swipe-cell__right {
  right: 0;
  -webkit-transform: translate3d(100%, 0, 0);
  transform: translate3d(100%, 0, 0);
}
.right {
  .van-button {
    height: 2.13333rem;
  }
}
// 新增
.buttons {
  position: fixed;
  height: 90px;
  bottom: 0;
  left: 0;
  right: 0;
  width: 750px;
  background-color: #f5f5f5;

  .van-button {
    margin: 0 20px;
    width: 710px;
    line-height: 90px;
  }
}
// 新增收货地址
.address {
  position: fixed;
  top: 110px;
  left: 0;
  right: 0;
  background-color: #f7f8fa;
  height: 100%;
  z-index: 1000;
  // 保存按钮
  ::v-deep .van-button--danger {
    color: #fff;
    background-color: #6d82c4;
    border: 1px solid #6d82c4;
  }
  // 取消按钮
  .qx {
    margin: -80px 20px;
    .van-button {
      border-radius: 50px;
      width: 710px;
    }
  }
}
::v-deep .van-switch--on {
  background-color: #6d82c4;
}
</style>
