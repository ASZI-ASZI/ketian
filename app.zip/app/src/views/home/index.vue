<template>
  <div class="goods">
    <van-search v-model="value" shape="round" background="pink" placeholder="请输入搜索关键词" />
    <div class="player-container">
      <video width="100%" height="20%" controls="false" autoplay="true" muted loop="loop">
        <source src="1.mp4" type="video/mp4" />
      </video>

      <van-button icon="smile" plain round type="info" size="large" color="red" disabled>可甜甜品店</van-button>
    </div>
    <!-- 下拉刷新 -->
    <van-pull-refresh v-model="isLoading" success-text="刷新成功" @refresh="onRefresh">
      <!-- 颜色背景+swipe -->

      <!-- 七图菜单 -->
      <home-server :resData="serverAdv"></home-server>
      <!-- 新鲜事 -->
      <div class="xxs">
        <!-- IndexHead -->
        <index-head />
        <home-xxs :xxsList="xxsList">
          
        </home-xxs>
      </div>
      <!-- 奶爸潮品 -->
      <div class="nbcp">
        <!-- IndexHead -->
        <index-head title="奶爸潮品" nIcon="arrow" />
        <!-- cp/产品 -->
        <home-cp :cpList="cpList" @toDetails="details"></home-cp>
      </div>
    </van-pull-refresh>
  </div>
</template>

<script>
//引入swipe组件
import HomeSwipe from "@/components/home/swipe.vue";
//引入server组件
import HomeServer from "@/components/home/server.vue";
// 引入IndexHead组件
import IndexHead from "@/components/common/IndexHead.vue";
// 引入xxs组件
import HomeXxs from "@/components/home/xxs.vue";
// 引入cpList
import HomeCp from "@/components/home/cp.vue";

import { getHomeCpList, getHomeTjList } from "@/api/home.js";

export default {
  components: {
    HomeSwipe,
    HomeServer,
    IndexHead,
    HomeXxs,
    HomeCp
  },
  data() {
    return {
      // 轮播图
      swipeList: [
        { url: "1", img: "https://img01.yzcdn.cn/vant/apple-1.jpg" },
        { url: "2", img: "https://img01.yzcdn.cn/vant/apple-2.jpg" },
        { url: "3", img: "https://img01.yzcdn.cn/vant/apple-1.jpg" },
        { url: "4", img: "https://img01.yzcdn.cn/vant/apple-2.jpg" }
      ],
      // 七图菜单
      serverAdv: {},
      // 新鲜事
      xxsList: [],
      // 奶爸潮品
      cpList: [],
      tjData: [],
      // 刷新
      isLoading: false
    };
  },

  created() {
    this.__init();
    this.getCpList();
    this.getTjList();
  },
  methods: {
    // 获取模拟数据
    async __init() {
      this.axios.get("/home/index").then(res => {
        let rul = res.data.data;
        this.xxsList = rul.xxsList;
        // this.cpList = rul.cpList;

        //七图菜单
        this.serverAdv = rul.serverAdv;
      });
    },
    async getCpList() {
      let result = await getHomeCpList();
      this.cpList = result.data;
      //console.log(this.cplist);
    },
    async getTjList() {
      let result = await getHomeTjList();
      this.tjData = result.data;
      // console.log(result);
    },
    // 轮播图点击事件
    event(item) {
      console.log(item.url);
    },
    // 刷新
    onRefresh() {
      setTimeout(() => {
        this.isLoading = false;
      }, 1000);
    },
    // 产品详情
    details(item) {
      //console.log(item);
      item.tjData = this.tjData;
      this.$router.push({
        path: "goods_details",
        query: { data: item }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
@import "~@/assets/scss/homeIndex";
</style>