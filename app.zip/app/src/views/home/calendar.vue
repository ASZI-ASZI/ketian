<template>
<div class="frame">
  		<van-nav-bar
			title="日历" 
			left-text="返回" 
			left-arrow
			@click-left="prev">
		</van-nav-bar>
  <van-calendar
  :poppable="false"
  :show-confirm="false"
  :style="{ height: '730px' }"
  color='#1989fa'
  type="range" :formatter="formatter"
/>
  </div>
</template>

<script>
import Vue from 'vue';
import { Calendar } from 'vant';
Vue.use(Calendar);
export default {
data() {
    return {
      date: '',
      show: true,
    };
  },
 methods: {
    formatter(day) {
      const month = day.date.getMonth() + 1;
      const date = day.date.getDate();

      if (month === 12) {
        if (date === 1) {
          day.text = '世界艾滋病日';
        } else if (date === 24) {
          day.text = '平安夜';
        }else if (date === 3) {
          day.text = '国际残疾人日';
        }else if (date === 13) {
          day.text = '南京大屠杀纪念日';
        } else if (date === 25) {
          day.text = '圣诞节';
        }
      }

      if (day.type === 'start') {
        day.bottomInfo = '入住酒店';
      } else if (day.type === 'end') {
        day.bottomInfo = '离开酒店';
      }

      return day;
    },
    prev() {
			this.$router.go(-1);
		},
 }
 
};
</script>

<style>
.frame{
  height: 1000px;
  width: 100%;
}
</style>