<template>
	<div>
		企业用户
	</div>
</template>

<script>
export default {};
</script>

<style scoped></style>
