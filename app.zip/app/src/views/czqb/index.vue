<template>
	<div>
		<!-- HeadNavBar -->
		<head-nav-bar :title="`充值钱包`"  />
		<!-- 充值卡列表 -->
		<div class="list" v-for="(item, index) in listData" :key="index">
			<!-- 列表内容 -->
			<div class="list_content">
				<!-- 价格 -->
				<div class="price">
					<small>￥</small>
					{{ item.price }}
				</div>
				<!-- 描述与进步器 -->
				<div class="desc_jbq">
					<div>{{ item.name }}</div>
					<div class="buttons"><van-stepper v-model="item.number" min="0" theme="round" button-size="26" disable-input /></div>
				</div>
			</div>
		</div>
		<!-- 赠送标题/赠送列表 -->
		<div v-if="this.isData.length > 0 ? 'isShow':''">
			<!-- 赠送标题 -->
			<div class="zs_title">
				<van-icon name="circle" color="#6D86C4" />
				优惠赠送
			</div>
			<!-- 赠送列表 -->
			<div class="list" v-for="(items, indexs) in isData" :key="indexs">
				<div class="list_content">
					<div class="price" style="background-color: #6d86c4;color: #fff;">
						<small>￥</small>
						{{ items.price }}
					</div>
					<div class="desc_jbq">
						<div>{{ items.name }}</div>
						<div class="buttons">x {{ items.number }}</div>
					</div>
				</div>
			</div>
			
		</div>
		<!-- 提交 -->
		<van-submit-bar
		label="应付合计" 
		:price="this.price"
		:disabled="this.price > 0 ? false : true"
		text-align="left" button-text="去结算" 
		tip="购买以上商品券享充1赠1,不同商品券均可一起购买!" 
		@submit="onSubmit" />
	</div>
</template>

<script>
//HeadNavBar
import HeadNavBar from '@/components/common/HeadNavBar.vue'
import ComLogin from '@/components/common/login_back.vue';
export default {
	components: { ComLogin,HeadNavBar },
	data() {
		return {
			isShow:false,
			// 充值卡列表
			listData: [
				{ id: 1, price: '68', name: 'A1全场通用', number: 0 },
				{ id: 2, price: '88', name: 'B1全场通用', number: 0 },
				{ id: 3, price: '188', name: 'C1全场通用', number: 0 }
			],
			//优惠赠送
			isData: [
				{ id: 1, price: '68', name: 'A1全场通用', number: '1' },
				{ id: 2, price: '88', name: 'B1全场通用', number: '2' },
				{ id: 3, price: '188', name: 'C1全场通用', number: '3' }
			],
			//价格统计
			price:33400,
		};
	},
	methods: {
		
		// 提交
		onSubmit() {
			this.$router.push('qrdd')
		}
	}
};
</script>

<style lang="scss" scoped>
// 充值卡列表
.list {
	margin: 20px 20px 20px 20px;
	height: 165px;
	width: 710px;
	background-color: white;
	border-radius: 10px;
	.list_content {
		display: flex;
		// 价格
		.price {
			background-color: #e8dcd3;
			height: 165px;
			width: 190px;
			display: flex;
			align-items: center;
			justify-content: center;
			color: #795023;
			font-size: 60px;
			> small {
				font-size: 40px;
			}
		}
		//描述与进步器
		.desc_jbq {
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: 30px;
			margin: 0 26px 0 26px;
			width: 494px;
			// Stepper 步进器
			.buttons {
				::v-deep .van-stepper__minus {
					color: #6d86c4;
					background-color: #fff;
					border: 1px solid #6d86c4;
				}

				::v-deep .van-stepper__plus {
					color: #fff;
					background-color: #6d86c4;
				}
			}
		}
	}
}
// 优惠赠送标题
.zs_title {
	display: flex;
	align-items: center;
	margin: 20px 20px 20px 20px;
	font-size: 30px;
	height: 50px;
	.van-icon {
		margin-right: 10px;
	}
}
// 提交按钮
	.van-submit-bar__button--danger {
	    background: #6d86c4;
	}
</style>
