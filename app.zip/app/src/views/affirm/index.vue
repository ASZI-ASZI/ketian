<template>
	<div>
		<!-- headerNavbar -->
		<head-nav-bar :title="`确认定单`" />
		<div class="time">
			配送时间 约2020-8-3 12:50送达
		</div>
		<!-- 配送方式 -->
		<way  :radioData="radioData" :radio="radio"
		 @change="change" :zqList="zqList"/>
		 <!-- 商品信息 -->
		<div class="shopInfo">
			<van-card
			  num="3"
			  tag="new"
			  price="29.00"
			  desc="250ml/三天"
			  title="新青年鲜奶"
			  thumb="https://img01.yzcdn.cn/vant/apple-1.jpg"
			  origin-price="50.00"
			/>
			
			<!-- 合计 -->
			<div class="hj">合计:￥33.6</div>
		</div>
		<!-- 钱包、优惠券-->
		<div class="qb_xhj">
			<van-cell-group>
			  <van-cell title="可甜钱包" value="无可用" />
			  <van-cell title="优惠券" value="无可用" />
			</van-cell-group>
		</div>
		<!-- 支付方式 -->
		<com-pay :resData="actions" :pay="pay" @onSelect="onSelect" @show="show"></com-pay>
		<!-- 支付协议 -->
		<div class="zfxy">
			<div class="title">
				<van-checkbox v-model="checked" label-disabled checked-color="#6d86c4" icon-size="20">
					<span>我已阅读并同意</span>
					<small class="small">《支付协议》</small>
				</van-checkbox>
				<div class="van-multi-ellipsis--l4">
				 {{zfxy.desc}}
				</div>
			</div>
		</div>
		<!-- 提交 -->
		<van-submit-bar label="应付合计"  
		:price="this.price" 
		:disabled="this.checked ? false : true"
		text-align="left" button-text="去结算" @submit="onSubmit" />
	</div>
</template>

<script>
	// headerNavbar
	import HeadNavBar from '@/components/common/HeadNavBar.vue'
	// 
	import way from '@/components/shops/way.vue'
	// 支付
	import ComPay from '@/components/common/pay.vue'
	
	export default {
		components: {
			HeadNavBar,way,ComPay
		},
		data() {
			return {
				//
				radio:'ps',
				//配送按钮
				radioData: [
					{name: 'ps',label: '配送',},
					{name: 'zq',label: '自取',}
				],
				// 自取数据
				zqList:[
					{
						title: '杭州梦想小镇店',
						label: '距您1.4km'
					}
				],
				//价格统计
				price:3360,
				// 复选
				checked: true,
				//pay
				pay:{
					radio: '3',
					isShow: false,
					icon:'alipay',
					value: 'alipay',
					title:'支付宝',
				},
				// 支付方式
				actions: [
					{ id: 1, name: '1', title: '奶爸钱包', value: 'nbqb',icon:'gold-coin',balance:'50' },
					{ id: 2, name: '2', title: '微信支付', value: 'wxpay',icon:'wechat',balance:'' },
					{ id: 3, name: '3', title: '支付宝',   value: 'alipay',icon:'alipay',balance:'' },
				],
				// 支付协议
				zfxy:{
					desc:'温馨提示：仅支持开具电子发票，订单完成后可前往发票管理中心开具。'
				}
			}
		},
		
		methods:{
			// 配送、自取
			change(item) {
				this.radio = item.name;
			},
			//显示
			show(){this.pay.isShow = true},
			//pay
			onSelect(item){
				this.pay.radio = item.name;
				this.pay.icon = item.icon;
				this.pay.isShow = false;
				this.pay.title = item.title;
				this.pay.value = item.value;
			},
			// 结算
			onSubmit() {
				this.$toast.success('结算成功！');
				this.$router.push({path:'/cart'});
			}
		}
	}
</script>

<style lang="scss" scoped>
	// 配送时间
	.time{
		height: 133px;
		line-height: 133px;
		font-size: 30px;
		font-weight: bold;
		text-align: center;
	}
	// 商品信息 
	.shopInfo{
		margin: 0 20px;
		border-radius: 10px;
		height: 100%;
		width: 710px;
		background-color: white;
		::v-deep .van-card{
			border-radius: 10px;
			background-color: white;
			width: 100%;
		}
		
		//合计
		.hj{
			margin-top: 20px;
			padding-bottom: 20px;
			// width: 710px;
			font-size: 30px;
			margin-left: 150px;
			font-weight: bolder;
		}
	}
	// 钱包、优惠券
	.qb_xhj{
		margin: 20px 20px 20px 20px;
		::v-deep .van-cell{
			border-radius: 10px;
		}
	}
	
	// 支付协议
	.zfxy{
		margin: 0px 50px 0 50px;
		height: 200px;
		// background-color: gray;
		// 标题、复选框
		.title{
			font-size: 30px;
			.small{
				color: #6d86c4;
			}
			.van-multi-ellipsis--l4{
				margin-top: 20px;
				font-size: 28px;
				line-height: 40px;
				color: #aca7af;
			}
		}
	}
	// 提交按钮
	.van-submit-bar__button--danger {
	    background: #6d86c4;
	}

</style>