<template>
	<div>
		<!-- 蓝色背景 -->
		<div class="cart_blue">
			<!-- 信息提示 -->
			<div class="xxts">
				<van-icon color="#fff" name="chat-o" size="28" 
				:dot="dot>0===true" 
				@click="news" />
			</div>

			<!-- 用户信息 -->
			<div class="user"  @click="login" v-if="islogin==false">
				<van-image :src="avatar" />
				<span class="text">
					立即登录
					<van-icon name="arrow" />
				</span>
			</div>

			<div class="user"  @click="loginout" v-if="islogin==true">
				<van-image :src="avatar" />
				<span class="text">
					登出
					<van-icon name="arrow" />
				</span>
			</div>

			
		</div>
		<!-- 余额、优惠、礼品、钱包 -->
		<user-info :resData="userData" @info="info"></user-info>
		<!-- 用户功能菜单 -->
		<user-gncd :resData="userGncd" @userInfo="userInfo"></user-gncd>
	    
		<!-- 单张广告 -->
		<div class="dzgg">
			<!-- <van-image fit="cover" lazy-load :src="img" ></van-image> -->
			<van-grid  :border="false" :column-num="3">
			  <van-grid-item v-for="(item,index) in imgList" :key="index">
			    <van-image fit="contain" lazy-load :src="item.img" />
			  </van-grid-item>
			</van-grid>
		</div>
	</div>
</template>

<script>
// userinfo
import UserInfo from '@/components/user/UserInfo.vue'
// usergncd
import UserGncd from '@/components/user/UserGncd.vue'
export default {
	components: {
		UserInfo,UserGncd
	},
	data() {
		return {
			islogin : false,
			// 默认头像
			avatar: require('@/assets/img/logo_1.png'),
			// 右上角小红点
			dot:2,
			// 用户信息,余额、优惠、礼品、钱包
			userData:[
				{title:'--元',subtitle:'账户余额',url:'zhye'},
				{title:'--张',subtitle:'奶爸钱包',url:'nbqb'},
				{title:'--张',subtitle:'优惠券',url:'coupon'},
				{title:'--张',subtitle:'礼品卡',url:'lpk'},
			],
			//用户功能菜单
			userGncd:[
				{icon:'cart-circle-o',title:'我的订单',url:'order'},
				{icon:'label-o',title:'发票管理',url:'bill'},
				{icon:'gift-card-o',title:'兑换优惠',url:'convert'},
				{icon:'vip-card-o',title:'企业账户',url:'enterprise'},
				{icon:'service-o',title:'我的客服',url:'service'},
			],
			
			imgList:[
				{
					id:1,
					img:require('@/assets/img/nn1.png'),
				},
				{
					id:2,
					img:require('@/assets/img/nn2.png'),
				},
				{
					id:3,
					img:require('@/assets/img/nn3.png'),
				}
			]
		};
	},
	created(){
		this.islogin = this.$store.getters['user/isLogin'];
		if(undefined == this.islogin ) 
			this.islogin = false

		//console.log(this.islogin);		
	},
	methods: {

		loginout(){
			this.$store.dispatch("user/logout");
			this.islogin=false;
		},

		//跳转登录
		login() {
			this.$router.push('login')
		},
		// 跳转消息中心
		news(){
			this.$router.push('news')
		},
		//余额、优惠、礼品、钱包  
		info(item){
			this.$router.push(item.url)
		},
		// 用户功能菜单
		userInfo(item){
			this.$router.push(item.url)
		}
		
	},
};
</script>

<style lang="scss" scoped>
@import '~@/assets/scss/userIndex'
</style>
