<template>
  <div class="content">
    <!-- 蓝色背景 -->
    <div class="cart_blue"></div>
    <!-- 轮播图 -->
    <s-swipe :resData="swipeList" />
    <!-- 自提、外送 -->
    <way :radioData="radioData" :zqList="zqList" />
    <!-- 菜单、商品滚动组件 -->
    <shops-bscroll :resData="shopsData" @toDetails="details" />
    <!-- 合计-->
    
    <total
      :totalNum="totalNum"
      :totalPrice="totalPrice"
      :settle="settle"
      :cartData="selectGoods"
    />
    <!-- 圆形菜单 -->
    <com-menu />
  </div>
</template>

<script>
//引入swipe组件
import SSwipe from "@/views/shops/components/SSwipe.vue";
// 配送方式
import way from "@/views/shops/components/way.vue";
// 引入Bscroll菜单、商品滚动组件
import ShopsBscroll from "@/views/shops/components/Bscroll.vue";
// 合计
import total from "@/views/shops/components/total.vue";

// 圆形菜单组件
import ComMenu from "@/components/common/ComMenu.vue";

import { getGoodsList } from "@/api/goods.js";

export default {
  components: { SSwipe, ShopsBscroll, total, way, ComMenu },

  data() {
    return {
      // 轮播图
      swipeList: [
        { url: "1", img: require("@/assets/img/shops1.png") },
        { url: "2", img: require("@/assets/img/shops2.png") },
        { url: "3", img: require("@/assets/img/shops3.png") },
        { url: "4", img: require("@/assets/img/shops4.png") },
      ],

      //配送按钮
      radioData: [
        { name: "ps", label: "配送" },
        { name: "zq", label: "自取" },
      ],

      // 自取数据
      zqList: [
        {
          title: "杭州梦想小镇店",
          label: "距您1.4km",
        },
      ],
      // 商品、菜单
      shopsData: [],
    };
  },

  // 合计费用
  computed: {
    //取得所有选中的商品
    selectGoods() {
      let arr = [];
      // 变历shopData-->count
      this.shopsData.forEach((item) => {
        item.content.forEach((items) => {
          if (items.count > 0) {
            arr.push(items);
          }
        });
      });
      return arr;
    },
    // 计算总价格
    totalPrice() {
      let price = 0;
      this.selectGoods.forEach((val) => {
        price += val.count * val.sprice;
      });
      return price;
    },
    // 筛选结算
    settle() {
      if (!this.totalPrice > 0) {
        return "免费配送";
      } else {
        return "立即购买";
      }
    },
    // 总数量
    totalNum() {
      let num = 0;
      this.selectGoods.forEach((val) => {
        num += val.count;
      });
      return num;
    },
  },
  created() {
    this.getShopsData();
  },
  methods: {
    async getShopsData() {
      try {
        let result = await getGoodsList();

        console.log(result);

        if (result.code == 1) {
          this.shopsData = result.data;
        }
      } catch (error) {
        console.log(error);
      }
    },
    // 产品详情
    details(item) {
      this.$router.push({
        path: "goods_details",
        query: { data: item },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
// Index
@import "~@/assets/scss/shopsIndex";
</style>
