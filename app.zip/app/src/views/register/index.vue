<template>
  <div>
      
    <div class>
      <van-cell-group>
        <van-field label="用户" v-model="regForm.name" type="text" placeholder="请输入用户" />

        <van-field label="密码" v-model="regForm.pwd" type="password" placeholder="请输入密码" />

        <van-field label="确认" v-model="regForm.pwd2" type="password" placeholder="请确认密码" />

        <van-field label="电话" v-model="regForm.phone" type="phone" placeholder="请输入dianhua" />

        <van-field label="地址" v-model="regForm.address" placeholder="请输入address" />

        

        <van-button @click="onClickRegister" type="primary" size="normal" block color="pink">注册</van-button>
      </van-cell-group>
      <van-divider :style="{ color: 'orange', borderColor: 'blue', padding: '20 11px' }">可甜甜品店欢迎您</van-divider>
    </div>
  </div>
</template>

<script>
import { register } from "@/api/user.js";

export default {
  data() {
    return {
      regForm: {
        name: "",
        pwd: "",
        pwd2: "",
        phone: "",
        address: ""
      }
    };
  },
  methods: {
    async onClickRegister() {
      if (this.regForm.name === "") {
        this.$toast("用户不能为空");
        return;
      } else if (this.regForm.pwd === "") {
        this.$toast("密码不能为空");
        return;
      } else if (this.regForm.pwd != this.regForm.pwd2) {
        this.$toast("密码两次输入不一致");
        return;
      } else if (this.regForm.phone === "") {
        this.$toast("电话不能为空");
        return;
      }

      try {
        let user = this.regForm;
        delete user.pwd2; //删除该临时的字段
        let result = await register(user);
        if (result.code === 1) {
          this.$store.commit("user/setUser", result.data.user); //保存用户信息，还是处于未登录
          this.$router.push({ name: "login" });
        }
      } catch (error) {
        this.$dialog.alert({ title: "注册失败", message: error });
      }
    }
  }
};
</script>

<style lang="less" scoped>
.content-padded {
  margin: 10px;
  color: pink;
  align-content: center;
}
</style>

