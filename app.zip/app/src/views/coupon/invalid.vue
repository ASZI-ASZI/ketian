<template>
	<div>
		<!-- 返回、登录 -->
		<!-- <com-login @prev="prev" :text="`无效的优惠券`"></com-login> -->
		<van-nav-bar
			title="无效的优惠券" 
			left-text="返回" 
			left-arrow
			@click-left="prev">
		</van-nav-bar>
		<!-- 优惠券 -->
		<van-list
		v-model="loading" 
		:finished="finished" 
		finished-text="已经全部加载完成" @load="onLoad">
			<coupon-index :resData="couponData" 
				@onLoad="onLoad" 
				:isShow="false">
			</coupon-index>
		</van-list>
	</div>
</template>

<script>
	//login_back
	import ComLogin from '@/components/common/login_back.vue';
	//coupon
	import CouponIndex from "./components/CouponIndex.vue";
	import { getCouponList } from "@/api/coupon.js";
	export default {
		components: {
			ComLogin,CouponIndex
		},
		data() {
			return {
				// 承载数据
				couponData: [],
				loading:false,
				finished:false
			}
		},
		async created(){
		this.getCouponDetils();
		
		try{
        let result = await getCouponList();

        console.log(result);

        if (result.code == 1) {
          this.couponData = result.data;
        }
      	} catch (error) {
        	console.log(error);
      	}	
	
	},
	
		methods: {
			prev() {
				this.$router.go(-1)
			},
			// 数据加载
			onLoad(){
				setTimeout(() => {
					this.couponData.push(
						// {
						// 	title:'限定饮品',
						// 	time:'有效期至2020-06-06',
						// 	zk:'3.8',
						// 	name:1,
						// 	desc:'1.本券可用于所有可甜商品。',
						// 	desc1:'2.本券一次使用1张限1件商品,自领取日起有效期3天。',
						// 	desc2:'3.本优惠券不与其他优惠同享。',
						// },
						// {
						// 	title:'限定饮品',
						// 	time:'有效期至2020-06-06',
						// 	zk:'3',
						// 	name:2,
						// 	desc:'1.本券可用于所有可甜商品。',
						// 	desc1:'2.本券一次使用1张限1件商品,自领取日起有效期3天。',
						// 	desc2:'3.本优惠券不与其他优惠同享。',
						// },
						// {
						// 	title:'限定饮品',
						// 	time:'有效期至2020-06-06',
						// 	zk:'2',
						// 	name:3,
						// 	desc:'1.本券可用于所有可甜商品。',
						// 	desc1:'2.本券一次使用1张限1件商品,自领取日起有效期3天。',
						// 	desc2:'3.本优惠券不与其他优惠同享。',
						// }
					)
					//加载状态结束
					this.loading = false
					// 数据加载完成
					if(this.couponData.length >=1){
						this.finished = true
					}
				},1000)
			},
			
		},
		
	}
</script>

<style scoped>

</style>