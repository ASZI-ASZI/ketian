<template>
  <div>
    <!-- headnavbar -->
    <head-nav-bar :title="`消息中心`" />
    <!-- 消息列表 -->
    <div class="news" v-for="(item,index) in newsData" :key="index" @click="desc">
      <!-- 内容 -->
      <div class="content">
        <span class="time">{{item.time}}</span>
        <span class="title">{{item.title}}</span>
        <span class="luck">恭喜您，{{item.title}}。</span>
      </div>
    </div>
  </div>
</template>

<script>
//headNavBar
import HeadNavBar from "@/components/common/HeadNavBar.vue";
import { getNewsList } from "@/api/news.js";
export default {
  components: { HeadNavBar },
  data() {
    return {
      //优惠券列表数据
      newsData: [
      	// {id:1,time:'2020-06-30 09:45',title:'您已获得1张3.8折限定饮品券'},
      	// {id:2,time:'2020-06-30 09:45',title:'您已获得1张全场饮品立减15元券'},
      	// {id:3,time:'2020-06-30 09:45',title:'您已获得1张1折限定饮品券'}
      ]
	}
  },
   async created() {
        let result = await getNewsList();
        if (result.code == 1) {
          this.newsData = result.data;
        }
      },
  methods: {
    //返回上一级
    prev() {
      this.$router.go(-1);
    },
    // 跳转到可用优惠券详情
    desc() {
      this.$router.push("coupon");
    }
  }
};
</script>

<style lang="scss" scoped>
// 消息列表
.news {
  display: flex;
  flex-direction: column;
  margin: 20px 20px 20px 20px;
  height: 160px;
  width: 710px;
  background-color: white;
  border-radius: 10px;
  // 内容
  .content {
    @extend .news;
    font-size: 30px;
    width: 670px;
    height: 120px;
    .time {
      color: #aeaeae;
    }
    .title {
      margin-top: 10px;
      margin-bottom: 10px;
    }
    .luck {
      @extend .time;
      font-size: 20px;
    }
  }
}
</style>
