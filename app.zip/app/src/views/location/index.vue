<template>

	<div>
		<!-- heade -->
		<head-nav-bar :title="`选择城市`" />
		<!-- 当前定位城市 -->
		<div class="a">
			<van-cell title="当前定位城市" />
		</div>
		<!-- 显示的当前定位城市 -->
		<div class="dwcs">
			<van-cell title="杭州" icon="location-o">
			  <!-- 使用 right-icon 插槽来自定义右侧图标 -->
			  <template #right-icon>
			    <van-icon name="replay"  color="#6d86c4"> </van-icon>
				<span class="span">重新定位</span>
			  </template>
			</van-cell>
		</div>
		<!-- 区域、地址 -->
		<van-index-bar>
			<van-index-anchor index="A" />
			<van-cell title="安庆" />
			<van-cell title="鞍山" />
			
			<van-index-anchor index="B" />
			<van-cell title="北京" />
			<van-cell title="滨江" />
		</van-index-bar>
	</div>
	
</template>

<script>
//head
import HeadNavBar from '@/components/common/HeadNavBar.vue'
export default {
	components: {
		HeadNavBar
	},
};
</script>

<style lang="scss" scoped>
	.van-cell{
		margin: 0 30px;
		width: 700px;
		border-radius: 10px;
	}
	.a{
		.van-cell{background-color: #f5f5f5;}
	}
	.dwcs{
		.van-icon {
			display: flex;
			align-items: center;
			justify-content: center;
		}
		.span{
			color: #6d86c4;
		}
	}
	
</style>
