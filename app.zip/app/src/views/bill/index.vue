<template>
	<div>
		<head-nav-bar title="发票管理" rightText="发票说明" @clickRight="clickRight" />
		<!-- 发票管理列表 -->
		<list :resData="list" @show="show" /> 
		<!-- 列表内容详情 -->
		<is-show :isShow="isShow" :listIndex="listIndex" @show="show" :img_wrap="img_wrap" />
		<!-- 发票说明 -->
		<explain :explain="explain" @clickRight="clickRight"/>
		
	</div>
</template>

<script>
import HeadNavBar from '@/components/common/HeadNavBar.vue';
import list from '@/components/bill/list.vue'
import isShow from '@/components/bill/isShow.vue'

// 发票说明
import explain from '@/components/bill/explain.vue'
export default {
	components: {
		HeadNavBar,list,isShow,explain
	},
	data() {
		return {
			// list
			list: [
				{
					data: [
						{ id: '1', name: '按订单开票' }, 
						{ id: '2', name: '钱包购买开票' }, 
						{ id: '3', name: '礼品卡购买开票' }, 
						{ id: '4', name: '充值开票' },
					]
				},
				{
					data: [
						{ id: '5', name: '发票记录' },
						{ id: '6', name: '发票抬头' }
					]
				}
			],
			isShow: false,
			// 发票说明
			explain:false,
			img_wrap: require('../../assets/img/order.png'),
			listIndex:{},
			
		};
	},
	created() {
		this.getList()
	},
	methods: {
		//发票说明
		clickRight() {
			this.explain = !this.explain;
		},
		// 显示列表内容详情
		show(items) {
			this.isShow = !this.isShow;
			this.$root.bus.$emit('showAction',items)
		},
		// 接收列表内容详情
		getList(){
			this.$root.bus.$on('showAction',v => {
				this.listIndex = v
			})
		}
	},
	// 移除
	beforeDestroy(){
		this.$root.bus.$off('showAction',this.getList())
	}
};
</script>

<style lang="scss" scoped>


</style>
