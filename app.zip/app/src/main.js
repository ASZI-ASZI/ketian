import Vue from 'vue'
import './plugins/axios'
import App from './App.vue'
import router from './router'
import 'vant/lib/index.css';
// app自适应
import 'amfe-flexible'

// vuex
import store from './store'
// 引入mixin（全局）
import loading from '@/components/mixin/loading.vue'
Vue.component('loading-plus',loading)

// 引入mock
import './mock'


import {Image as VanImage , Lazyload,Button,Tabbar,
TabbarItem,Swipe, SwipeItem,Icon,PullRefresh,Empty,Divider
,RadioGroup, Radio,Checkbox, CheckboxGroup,Stepper,SubmitBar
,SwipeCell,Cell, CellGroup,Card,Dialog,Sticky,Toast,Form,Field
,NumberKeyboard,Col,Row,Collapse, CollapseItem,List,Tag,DropdownMenu
,DropdownItem,ActionSheet,Popup,Switch,SidebarItem,Sidebar,TreeSelect
,Tabs,Tab,Grid,GridItem,IndexBar,IndexAnchor,Notify,Sku,NavBar,AddressList
,AddressEdit,Area,CouponList,CouponCell,ContactCard, ContactList, ContactEdit
,Steps,Step,Loading,Search
} from 'vant';

Vue.use(Button).use(Tabbar).use(TabbarItem)
.use(Swipe).use(SwipeItem).use(VanImage).use(Lazyload)
.use(Icon).use(PullRefresh).use(Empty).use(Divider).use(Radio)
.use(RadioGroup).use(CheckboxGroup).use(Checkbox).use(Stepper)
.use(SubmitBar).use(SwipeCell).use(Cell).use(CellGroup).use(Card)
.use(Dialog).use(Sticky).use(Toast).use(Form).use(Field).use(NumberKeyboard)
.use(Row).use(Col).use(Collapse).use(CollapseItem).use(List).use(Tag)
.use(DropdownMenu).use(DropdownItem).use(ActionSheet).use(Popup).use(Switch)
.use(SidebarItem).use(Sidebar).use(TreeSelect).use(Tabs).use(Tab).use(Grid)
.use(GridItem).use(IndexBar).use(IndexAnchor).use(Notify).use(Sku).use(NavBar)
.use(AddressList).use(AddressEdit).use(Area).use(CouponList).use(CouponCell)
.use(ContactCard).use(ContactList).use(ContactEdit).use(Steps).use(Step)
.use(Loading).use(Search)
;


import AMap from 'vue-amap';

// 高德地图
Vue.use(AMap);

  // 初始化vue-amap
AMap.initAMapApiLoader({
  // 高德key
  key: 'a5d279049e880444f2d18521da82f0a8',
  // 插件集合 （插件按需引入）
  plugin: ['AMap.Autocomplete', 'AMap.PlaceSearch', 'AMap.Scale', 'AMap.OverView', 'AMap.ToolBar', 'AMap.MapType', 'AMap.PolyEditor', 'AMap.CircleEditor']
});
Vue.config.productionTip = false
// 跳转后返回顶部
 router.afterEach((to,from,next) => {
      window.scrollTo(0,0);
 })
new Vue({
  router,
  store,
  render: h => h(App),
  data() {
  	return {
  		bus: new Vue()
  	}
  },
}).$mount('#app')
