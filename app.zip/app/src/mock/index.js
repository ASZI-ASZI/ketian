import Mock from 'mockjs'
// 请求响应时间
Mock.setup({
	timeout:'200-600'
})

// 引入模拟数据
import goodApi from './api/goods.js'
 // 接口(正则表示(/home/index))
 Mock.mock(/\/home\/index/,'get',goodApi.getData)