import Mock from 'mockjs'
let Random = Mock.Random
// 轮播图
let swipeList = []
export default {
	getData: () => {
		// 新鲜事
		let xxsList = []
		// for (let i = 0; i < 4; i++) {
		// 	xxsList.push({
		// 		id: Random.increment(),
		// 		url: Random.url(),
		// 		img:'https://img01.yzcdn.cn/vant/apple-2.jpg',

		// 	})
		// }

		xxsList.push({
			id: Random.increment(),
			url: Random.url(),
			img:"1.mp4"
		 


		});
		xxsList.push({
			id: Random.increment(),
			url: Random.url(),
			img:"1.mp4"

		});
		xxsList.push({
			id: Random.increment(),
			url: Random.url(),
			img:"1.mp4"

		});
		xxsList.push({
			id: Random.increment(),
			url: Random.url(),
			img:"1.mp4"

		});


		// 奶爸潮品数据
		let cpList = []
		for (let j = 0; j < 4; j++) {
			cpList.push({
				id: Random.increment(),
				cover: 'https://img01.yzcdn.cn/vant/apple-2.jpg',
				header: Random.pick(['潮品自营']),
				cpgg_title: Random.pick(['新儿童鲜奶', '新青年鲜奶', '中年鲜奶', '老年鲜奶']),
				sub_title: Random.pick(['children milk', 'teenagers milk', 'middle milk', 'elderly milk']),
				// 选中的商品属性
				attrs: [
					{
						id: 1,
						title: '容量',
						selected: 0,
						list: [
							{ name: '250ml' },
							{ name: '480ml' },
							{ name: '500ml' }
						]
					},
					{
						id: 2,
						title: '模式',
						selected: 0,
						list: [
							{ name: '三天' },
							{ name: '每周' },
							{ name: '每月' }
						]
					}
				],
				// 推荐
				tjData: [
					{
						img: 'https://img01.yzcdn.cn/vant/apple-1.jpg',
						title: Random.pick(['新儿童鲜奶']),
						sub_title: Random.pick(['children milk']),
						Sprice: 11,
						Oprice: 33
					},
					{
						img: 'https://img01.yzcdn.cn/vant/apple-2.jpg',
						title: Random.pick(['早鲜奶']),
						sub_title: 'children milk',
						Sprice: Random.float(8, 50, 0, 0),
						Oprice: Random.float(50, 100, 0, 0)
					}
				],
				//销量
				numb: Random.integer(1000, 2000),
				// 奶爸说
				nbs_title: Random.pick(['奶爸说']),
				// 头像
				avatar:'https://img01.yzcdn.cn/vant/apple-2.jpg',
				nbs_name: Random.pick(['中国好奶爸']),
				desc: Random.pick(['现在的孩子都是奶孩子，你要当好一个好奶爸！']),
				spxq_title: Random.pick(['商品详情']),
				spxq_descs: Random.pick([
					'独特的风味，本产品不含任何**成份，请放心使用，建议轻摇后再饮用。主要原材料:牛奶、白糖。本产品仅供冷饮，图片仅供参考，请以实物为准。建议送达后，请在保质期内饮用。'
				]),
				Sprice: Random.float(8, 50, 0, 0),
				Oprice: Random.float(50, 100, 0, 0),
				count: 1,//购买默认数量
				minnum: 1,
				maxnum: 50//该商品最大商品数，与库存有关
			})
		}
		// 猜你喜欢数据
		let cnxhList = []
		for (let j = 0; j < 10; j++) {
			cnxhList.push({
				id: Random.increment(),
				cover: 'https://img01.yzcdn.cn/vant/apple-2.jpg',
				header: Random.pick(['潮品自营']),
				cpgg_title: Random.pick(['新儿童鲜奶', '新青年鲜奶', '中年鲜奶', '老年鲜奶']),
				sub_title: Random.pick(['children milk', 'teenagers milk', 'middle milk', 'elderly milk']),
				// 选中的商品属性
				attrs: [
					{
						id: 1,
						title: '容量',
						selected: 0,
						list: [
							{ name: '250ml' },
							{ name: '480ml' },
							{ name: '500ml' }
						]
					},
					{
						id: 2,
						title: '模式',
						selected: 0,
						list: [
							{ name: '三天' },
							{ name: '每周' },
							{ name: '每月' }
						]
					}
				],
				// 推荐
				tjData: [
					{
						img: 'https://img01.yzcdn.cn/vant/apple-2.jpg',
						title: Random.pick(['新儿童鲜奶']),
						sub_title: Random.pick(['children milk']),
						Sprice: 11,
						Oprice: 33
					},
					{
						img: 'https://img01.yzcdn.cn/vant/apple-1.jpg',
						title: Random.pick(['早鲜奶']),
						sub_title: 'children milk',
						Sprice: Random.float(8, 50, 0, 0),
						Oprice: Random.float(50, 100, 0, 0)
					}
				],
				//销量
				numb: Random.integer(1000, 2000),
				// 奶爸说
				nbs_title: Random.pick(['奶爸说']),
				// 头像
				avatar: Random.image(),
				nbs_name: Random.pick(['中国好奶爸']),
				desc: Random.pick(['现在的孩子都是奶孩子，你要当好一个好奶爸！']),
				spxq_title: Random.pick(['商品详情']),
				spxq_descs: Random.pick([
					'独特的风味，本产品不含任何**成份，请放心使用，建议轻摇后再饮用。主要原材料:牛奶、白糖。本产品仅供冷饮，图片仅供参考，请以实物为准。建议送达后，请在保质期内饮用。'
				]),
				Sprice: Random.float(8, 50, 0, 0),
				Oprice: Random.float(50, 100, 0, 0),
				count: 0,//购买默认数量

			})
		}

		return {
			code: 20000,
			data: {
			  cpList,
			  xxsList,
			  cnxhList,
			  // 七图菜单
			  serverAdv: {
				xzxd: require('@/assets/img/ktjp.jpg'),
				wdqb: Random.pick(['我的钱包']),
				nbjx: require('@/assets/img/kttr.jpg'),
				stnn: Random.pick(['送TA牛奶']),
				nbcp: require('@/assets/img/ktcp.jpg'),
				nbhs: require('@/assets/img/kths.jpg'),
				nbyh: require('@/assets/img/ktyh.jpg')
			  }
	  
			}
		  }
		}
	  }