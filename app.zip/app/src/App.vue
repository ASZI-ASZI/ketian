<template>
	<div id="app">
		<router-view />
	</div>
</template>

<script>
export default {
	name: 'App'
};
</script>

<style>
/* total弹框 */
.van-dialog {
	z-index: 9999 !important;
}
body {
	padding-bottom: 160px;
	background-color: #f5f5f5;
	/* 字体显示清楚 */
	-webkit-font-smoothing: antialiased;
}
</style>
